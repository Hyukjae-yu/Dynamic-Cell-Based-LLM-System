#include "MmapStorageManager.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#define MINJI_MAGIC_NUMBER 0x4D494E4A 

MmapStorageManager::MmapStorageManager() 
    : baseAddress(nullptr), mappedLength(0), fileDescriptor(-1), header(nullptr), chosungIndexPtr(nullptr) {}

MmapStorageManager::~MmapStorageManager() { shutDown(); }

bool MmapStorageManager::initializeMasterFile(const char* filePath) {
    struct stat st = {0};
    if (stat(SYSTEM_DIR_PATH, &st) == -1) {
        mkdir(SYSTEM_DIR_PATH, 0700);
    }

    fileDescriptor = open(filePath, O_RDWR | O_CREAT, 0600);
    if (fileDescriptor < 0) return false;

    fstat(fileDescriptor, &st);
    bool isNewFile = (st.st_size == 0);

    size_t headerSize = sizeof(ExecHeader_t);
    size_t chosungIndexSize = sizeof(uint32_t) * 1024; 
    size_t execSize = sizeof(VirtualExecutionEngine::ExecutionContext) * DEFAULT_EXECUTION_CONTEXT_COUNT;
    
    // [신설] 확장 실행 코드 메모리 영역 크기 계산 산입!
    size_t execBlockSize = sizeof(VirtualExecutionEngine::ExecBlock) * DEFAULT_EXEC_BLOCK_COUNT;
    
    size_t tCellSize = sizeof(TokenPerceptionEngine::tCell) * DEFAULT_TOKEN_CELL_COUNT;
    size_t tCellConnSize = sizeof(TokenPerceptionEngine::tCellConn) * DEFAULT_CONN_COUNT;
    size_t cellSize = sizeof(BrainNetworkEngine::Cell) * DEFAULT_MEANING_CELL_COUNT;
    size_t cellConnSize = sizeof(BrainNetworkEngine::CellConn) * DEFAULT_CONN_COUNT;

    // 전체 가상메모리 크기 누적에 확장 영역 공간 끼워넣기
    size_t totalSize = headerSize + chosungIndexSize + execSize + execBlockSize + tCellSize + tCellConnSize + cellSize + cellConnSize;

    if (isNewFile) {
        if (ftruncate(fileDescriptor, totalSize) == -1) {
            close(fileDescriptor);
            return false;
        }
        mappedLength = totalSize;
    } else {
        mappedLength = st.st_size;
    }

    baseAddress = mmap(nullptr, mappedLength, PROT_READ | PROT_WRITE, MAP_SHARED, fileDescriptor, 0);
    if (baseAddress == MAP_FAILED) {
        close(fileDescriptor);
        return false;
    }

    header = reinterpret_cast<ExecHeader_t*>(baseAddress);

    if (isNewFile) {
        header->magicNumber = MINJI_MAGIC_NUMBER;
        header->version = 3; // vCPU 2단계 체이닝 인프라 버전 3으로 업그레이드!
        header->execCount = DEFAULT_EXECUTION_CONTEXT_COUNT;
        header->execBlockCount = DEFAULT_EXEC_BLOCK_COUNT; // 헤더에 수량 박기
        header->tCellCount = DEFAULT_TOKEN_CELL_COUNT;
        header->tCellConnCount = DEFAULT_CONN_COUNT;
        header->cellCount = DEFAULT_MEANING_CELL_COUNT;
        header->cellConnCount = DEFAULT_CONN_COUNT;
        
        uint32_t* idxPtr = reinterpret_cast<uint32_t*>(static_cast<char*>(baseAddress) + headerSize);
        for (int i = 0; i < 1024; ++i) idxPtr[i] = 0xFFFFFFFF;
    }

    chosungIndexPtr = reinterpret_cast<uint32_t*>(static_cast<char*>(baseAddress) + headerSize);

    // 🌟 정밀 오프셋 샌드위치 바인딩 시작!
    size_t currentOffset = headerSize + chosungIndexSize;
    
    // 1단계: 기존 vCPU 루트 레지스트리 바인딩
    execArray.bindMemory(baseAddress, currentOffset, header->execCount);
    currentOffset += sizeof(VirtualExecutionEngine::ExecutionContext) * header->execCount;

    // 2단계: [신설] 오빠가 구상한 가변 확장 블록 메모리 영역 바인딩 완료!
    execBlockArray.bindMemory(baseAddress, currentOffset, header->execBlockCount);
    currentOffset += sizeof(VirtualExecutionEngine::ExecBlock) * header->execBlockCount;

    // 3단계: 뒤쪽의 토큰 및 의미셀들은 새로운 오프셋 뒤로 완벽하게 밀어주어 데이터 무결성 보호!
    tCellArray.bindMemory(baseAddress, currentOffset, header->tCellCount);
    currentOffset += sizeof(TokenPerceptionEngine::tCell) * header->tCellCount;

    tCellConnArray.bindMemory(baseAddress, currentOffset, header->tCellConnCount);
    currentOffset += sizeof(TokenPerceptionEngine::tCellConn) * header->tCellConnCount;

    cellArray.bindMemory(baseAddress, currentOffset, header->cellCount);
    currentOffset += sizeof(BrainNetworkEngine::Cell) * header->cellCount;

    cellConnArray.bindMemory(baseAddress, currentOffset, header->cellConnCount);

    return true;
}

void MmapStorageManager::syncToDisk() { if (baseAddress != nullptr && mappedLength > 0) msync(baseAddress, mappedLength, MS_SYNC); }
void MmapStorageManager::shutDown() {
    if (baseAddress != nullptr && baseAddress != MAP_FAILED) {
        syncToDisk();
        munmap(baseAddress, mappedLength);
        baseAddress = nullptr;
        chosungIndexPtr = nullptr;
    }
    if (fileDescriptor >= 0) { close(fileDescriptor); fileDescriptor = -1; }
}
uint32_t MmapStorageManager::getChosungHead(uint16_t slotIdx) { return (chosungIndexPtr && slotIdx < 1024) ? chosungIndexPtr[slotIdx] : 0xFFFFFFFF; }
void MmapStorageManager::setChosungHead(uint16_t slotIdx, uint32_t tokenID) { if (chosungIndexPtr && slotIdx < 1024) chosungIndexPtr[slotIdx] = tokenID; }