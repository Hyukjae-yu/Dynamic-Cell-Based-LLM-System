#ifndef __CELL_MATH_HPP__
#define __CELL_MATH_HPP__

#include <stdint.h>
#include <stdbool.h>
#include <math.h>

// 128비트 정수형 정의 (64비트 컴파일러 내장 구조 활용)
typedef __int128_t int128;

// =============================================================================
// [오리지널 고정소수점 데이터 구조체 정의] - 메모리 낭비 없는 경량 규격
// =============================================================================

// 64비트 정수부 + 64비트 소수부 (총 128비트)
typedef struct {
    int64_t i;  // 정수부
    uint64_t f; // 소수부
} fixed128_t;

// 32비트 정수부 + 32비트 소수부 (총 64비트)
typedef struct {
    int32_t i;  // 정수부
    uint32_t f; // 소수부
} fixed64_t;

// 16비트 정수부 + 16비트 소수부 (총 32비트)
typedef struct {
    int16_t i;  // 정수부
    uint16_t f; // 소수부
} fixed32_t;

// 8비트 정수부 + 8비트 소수부 (총 16비트)
typedef struct {
    char i;     // 정수부
    uint8_t f;  // 소수부
} fixed16_t;


// =============================================================================
// [C++ 연산자 오버로딩] - 글로벌 영역 선언
// =============================================================================
fixed16_t  operator+(fixed16_t a, fixed16_t b);
fixed16_t  operator-(fixed16_t a, fixed16_t b);
fixed32_t  operator+(fixed32_t a, fixed32_t b);
fixed32_t  operator-(fixed32_t a, fixed32_t b);
fixed64_t  operator+(fixed64_t a, fixed64_t b);
fixed64_t  operator-(fixed64_t a, fixed64_t b);
fixed64_t  operator*(fixed64_t a, fixed64_t b);
fixed64_t  operator/(fixed64_t a, fixed64_t b);
fixed128_t operator+(fixed128_t a, fixed128_t b);
fixed128_t operator-(fixed128_t a, fixed128_t b);

// =============================================================================
// 🧮 CellMath 마스터 클래스
// =============================================================================
class CellMath {
public:
    // 전역 상수 선언부
    static fixed128_t F128_PI;
    static fixed128_t F128_HALF_PI;
    static fixed128_t F128_LN2;
    static fixed64_t  pi_fixed64;
    static fixed64_t  pi_over_2_fixed64;
    static fixed64_t  zero_fixed64;
    static fixed64_t  one_fixed64;
    static fixed16_t  tWeight_0;
    static fixed16_t  tWeight_1;

    // 상수 초기화 함수들
    static void initFixed16();
    static void initFixed32();
    static void initFixed64();
    static void initFixed128();

    // Raw 포맷 상호 변환 헬퍼 (통짜 정수 <-> 구조체)
    static int64_t   to_raw(fixed64_t a);
    static fixed64_t from_raw(int64_t raw);

    // -------------------------------------------------------------------------
    // 1. Q32.32 (64비트 고정소수점) 연산 함수군
    // -------------------------------------------------------------------------
    static fixed64_t double_to_fixed64(double val);
    static double    fixed64_to_double(fixed64_t f);
    static char      fixed64_polarity(fixed64_t value);
    static int       fixed64_cmp(fixed64_t a, fixed64_t b);
    
    static fixed64_t fixed64_add(fixed64_t a, fixed64_t b);
    static fixed64_t fixed64_sub(fixed64_t a, fixed64_t b);
    static fixed64_t fixed64_mul(fixed64_t a, fixed64_t b);
    static fixed64_t fixed64_div(fixed64_t a, fixed64_t b);
    static fixed64_t fixed64_calculate(fixed64_t a, fixed64_t b, char op);
    
    static fixed64_t fixed64_sin(fixed64_t x);
    static fixed64_t fixed64_cos(fixed64_t x);

    // -------------------------------------------------------------------------
    // 2. Q64.64 (128비트 고정소수점) 연산 함수군
    // -------------------------------------------------------------------------
    static char        fixed128_polarity(fixed128_t value);
    static fixed128_t f128_add(fixed128_t a, fixed128_t b);
    static fixed128_t f128_sub(fixed128_t a, fixed128_t b);
    static fixed128_t f128_mul(fixed128_t a, fixed128_t b);
    static fixed128_t f128_div(fixed128_t a, fixed128_t b);
    static fixed128_t f128_sqrt(fixed128_t a);
    static fixed128_t f128_pow(fixed128_t base, int32_t exp);
    
    static fixed128_t double_to_fixed128(double d);
    static double      fixed128_to_double(fixed128_t a);
    static fixed128_t float128_to_fixed128(__float128 q);
    static __float128 fixed128_to_float128(fixed128_t a);
    
    static fixed128_t f128_sin(fixed128_t x);
    static fixed128_t f128_cos(fixed128_t x);
    static fixed128_t f128_ln(fixed128_t x);

    // -------------------------------------------------------------------------
    // 3. Q16.16 (32비트 고정소수점) 연산 함수군
    // -------------------------------------------------------------------------
    static int32_t   fixed32_to_int32(fixed32_t a);
    static fixed32_t int32_to_fixed32(int32_t a);
    static fixed32_t fixed32_add(fixed32_t a, fixed32_t b);
    static fixed32_t fixed32_sub(fixed32_t a, fixed32_t b);
    static fixed32_t fixed32_mul(fixed32_t a, fixed32_t b);
    static fixed32_t fixed32_div(fixed32_t a, fixed32_t b);
    static fixed32_t Double_to_fixed32(double d);
    static double    Fixed32_to_double(fixed32_t f32);

    // -------------------------------------------------------------------------
    // 4. Q8.8 (16비트 고정소수점) 및 교차 변환 함수군
    // -------------------------------------------------------------------------
    static int16_t   fixed16_to_int16(fixed16_t a);
    static fixed16_t int16_to_fixed16(int16_t a);
    static fixed16_t fixed16_add(fixed16_t a, fixed16_t b);
    static fixed16_t fixed16_sub(fixed16_t a, fixed16_t b);
    static fixed16_t fixed16_mul(fixed16_t a, fixed16_t b);
    static fixed16_t fixed16_div(fixed16_t a, fixed16_t b);
    
    static fixed16_t float_to_fixed16(float f_val);
    static float     fixed16_to_float(fixed16_t a);
    static fixed32_t float_to_fixed32(float f_val);
    static float     fixed32_to_float(fixed32_t a);
    static fixed64_t fixed16_to_fixed64(fixed16_t a);

    // -------------------------------------------------------------------------
    // 5. 신경망 내부 학습 규칙 및 유틸리티 엔진 함수군
    // -------------------------------------------------------------------------
    static fixed64_t fixed64_hebbian_update(fixed64_t current_weight, fixed64_t input, fixed64_t output, fixed64_t eta);
    static fixed64_t fixed64_oja_update(fixed64_t current_weight, fixed64_t input, fixed64_t output, fixed64_t eta);
    
    static int128    extended_gcd_128(int128 a, int128 b, int128 *x, int128 *y);
    static int64_t   fixed_point_mul(int64_t a, int64_t b);
    
    static int       solve_fixed_point_combination(int64_t input_values[256], int64_t target_value, int64_t output_factors[256]);
    static int       solve_approx_fixed_point(int64_t inputs[256], int64_t target, int64_t factors[256]);
    
    static void      apply_oja_rule_with_relu(float* inputs, float* weights, int size, float learning_rate, float* output_ptr);
    static char      getPositionOfBitSet(uint8_t byte, uint32_t* buffer, uint32_t offset);
    static fixed64_t get_adaptive_threshold_fixed(fixed64_t* inputs, int size, fixed64_t sensitivity);

    // 내부 연산 전용 고속 인라인 함수들
    static inline int64_t fixed_mul(int64_t a, int64_t b) {
        return (int64_t)(((__int128_t)a * b) >> 32);
    }
    static inline int64_t fixed_sqrt(int64_t val) {
        if (val < 0) return 0;
        __int128_t temp = (__int128_t)val << 32;
        __int128_t res = 0;
        __int128_t bit = (__int128_t)1 << 126;
        while (bit > temp) bit >>= 2;
        while (bit != 0) {
            if (temp >= res + bit) {
                temp -= res + bit;
                res = (res >> 1) + bit;
            } else {
                res >>= 1;
            }
            bit >>= 2;
        }
        return (int64_t)res;
    }
};

#endif