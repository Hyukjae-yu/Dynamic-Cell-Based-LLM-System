#ifndef __TOKENPERCEPTIONENGINE_HPP__
#define __TOKENPERCEPTIONENGINE_HPP__

#include "cellTypes.hpp"

class TokenPerceptionEngine {
public:
    class tCellConn;

    class tCell {
    private:
        uint32_t id;
        char alias[NICKNAME_LENGTHt];
        fixed64_t energy;
        fixed64_t threshold;
        int32_t toPrevious; // 정렬을 보장해줄 양방향 링크드 상대 인덱스 변수들
        int32_t toNext;
        uint32_t targetID[MAX_TOKEN_CONNECTIONS];
        uint32_t tConnectionOffset;
        
        bool activeFlag;   
        bool learnable;
        bool execFlag;

    public:
        void initCell(uint32_t newID);
        void setID(uint32_t newID);
        uint32_t getID() const;
        void setAlias(const char* name);
        const char* getAlias() const;
        
        // 에너지 및 스레시홀드 제어
        void setEnergy(fixed64_t e);
        fixed64_t getEnergy() const;
        void addEnergy(fixed64_t e);
        void subEnergy(fixed64_t e);
        void clearEnergy(); 
        
        void setThreshold(fixed64_t t);
        fixed64_t getThreshold() const;
        bool isOverThreshold() const;
        
        // 체이닝 연결 제어
        void setNext(int32_t relativePos);
        int32_t getNext() const;
        void setPrev(int32_t relativePos);
        int32_t getPrev() const;

        // 타겟 의미셀 제어
        bool addTarget(uint32_t mCellID);
        void removeTarget(uint32_t mCellID);
        int findTarget(uint32_t mCellID) const;
        uint32_t getTargetID(int index) const;
        int getUsedTargetCount() const;  
        void clearAllTargets();          

        // 상태 플래그 제어
        void setConnOffset(uint32_t offset);
        uint32_t getConnOffset() const;
        
        void setActive(bool flag);       
        bool isActive() const;           
        void toggleActive();             
        
        void setLearnable(bool flag);
        bool isLearnable() const;
        void setExecFlag(bool flag);
        bool isExec() const;

        // 학습 및 추론 코어
        void trainPattern(const char* targetWord, TokenPerceptionEngine::tCellConn* connPool, size_t connPoolSize, int epochs);
        fixed64_t perceive(const char* inputWord, const TokenPerceptionEngine::tCellConn* connPool) const;
        void autoSetThreshold(const TokenPerceptionEngine::tCellConn* connPool, double ratio = 0.95);
    };

    class tCellConn {
    private:
        int32_t toPrevious;
        int32_t toNext;
        fixed16_t weight[MAX_TOKEN_INPUTS];

    public:
        void reset();
        void clearWeights(); 
        
        void setNextChunk(int32_t relativePos);
        int32_t getNextChunk() const;
        void setPrevChunk(int32_t relativePos);
        int32_t getPrevChunk() const;
        bool hasNext() const;
        bool hasPrev() const;

        bool isEmpty() const;
        bool isFull() const; 
        int getUsedCount() const; 

        fixed16_t getWeight(int slot) const;
        void setWeight(int slot, fixed16_t w);
        void addWeight(int slot, fixed16_t w);
        void subWeight(int slot, fixed16_t w);
    };

    static int32_t findFreeTConnChunk(tCellConn* connPool, size_t connPoolSize);

    // 🔥 오빠가 말한 초성 내비게이션 시스템 운영용 코어 멤버 함수 4형제 배치 완료
    static uint16_t mapEojeolToSlot(const char* eojeol);
    static bool addTokenToChosungChain(tCell* pool, size_t poolSize, uint32_t* chosungIndexPtr, uint32_t newTokenID, const char* alias);
    static int buildInferenceIndexBuffer(const char* inputSentence, uint32_t* chosungIndexPtr, uint32_t* tmpBuffer, int maxBufferSize);
    static void scanActiveChosungChains(tCell* pool, const tCellConn* connPool, const uint32_t* tmpBuffer, int bufferSize, const char* inputSentence);

    TokenPerceptionEngine();
    ~TokenPerceptionEngine();
};

#endif