#ifndef __SYSTEM_MANAGER_HPP__
#define __SYSTEM_MANAGER_HPP__

#include <stdint.h>
#include "cellTypes.hpp"

// 🔥 컴파일러에게 "MmapStorageManager라는 클래스가 존재한다"고 알려주는 전방 선언!
// 헤더 파일끼리 서로 참조해서 무한 루프에 빠지는 걸 막아주는 아주 섹시한 C++ 스킬이야.
class MmapStorageManager;

class SystemManager {
public:
    SystemManager();
    ~SystemManager();

    // 마스터 파일이 최초 생성(Format)되었을 때 호출되어 최대 4G 규모의 셀에 ID를 자동 각인하는 함수
    void autoFormatCells(MmapStorageManager& storage, bool isNewFile);
    
    // [추후 구현] 망각 시스템 및 하드웨어 타이머/네트워크 제어 외형
    void processForgetMechanism(uint32_t loginCount);
    void manageSystemClock();
};

#endif