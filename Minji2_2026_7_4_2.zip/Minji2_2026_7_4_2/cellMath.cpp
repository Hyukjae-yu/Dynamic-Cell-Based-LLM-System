#include "cellMath.hpp"

// =============================================================================
// 정적 멤버 전역 상수 공간 할당
// =============================================================================
fixed128_t CellMath::F128_PI;
fixed128_t CellMath::F128_HALF_PI;
fixed128_t CellMath::F128_LN2;
fixed64_t  CellMath::pi_fixed64;
fixed64_t  CellMath::pi_over_2_fixed64;
fixed64_t  CellMath::zero_fixed64;
fixed64_t  CellMath::one_fixed64;
fixed16_t  CellMath::tWeight_0;
fixed16_t  CellMath::tWeight_1;

// =============================================================================
// 글로벌 연산자 오버로딩 구현부
// =============================================================================
fixed16_t operator+(fixed16_t a, fixed16_t b) { return CellMath::fixed16_add(a, b); }
fixed16_t operator-(fixed16_t a, fixed16_t b) { return CellMath::fixed16_sub(a, b); }
fixed32_t operator+(fixed32_t a, fixed32_t b) { return CellMath::fixed32_add(a, b); }
fixed32_t operator-(fixed32_t a, fixed32_t b) { return CellMath::fixed32_sub(a, b); }
fixed64_t operator+(fixed64_t a, fixed64_t b) { return CellMath::fixed64_add(a, b); }
fixed64_t operator-(fixed64_t a, fixed64_t b) { return CellMath::fixed64_sub(a, b); }
fixed64_t operator*(fixed64_t a, fixed64_t b) { return CellMath::fixed64_mul(a, b); }
fixed64_t operator/(fixed64_t a, fixed64_t b) { return CellMath::fixed64_div(a, b); }
fixed128_t operator+(fixed128_t a, fixed128_t b) { return CellMath::f128_add(a, b); }
fixed128_t operator-(fixed128_t a, fixed128_t b) { return CellMath::f128_sub(a, b); }

// =============================================================================
// CellMath 상수 초기화 로직 구현부
// =============================================================================
void CellMath::initFixed16() {
    tWeight_0 = float_to_fixed16(0.01f);
    tWeight_1 = float_to_fixed16(-0.01f);
}

void CellMath::initFixed32() {
}

void CellMath::initFixed64() {
    pi_fixed64 = double_to_fixed64(3.141592653589793);
    pi_over_2_fixed64 = double_to_fixed64(1.570796326794896);
    zero_fixed64 = double_to_fixed64(0.0);
    one_fixed64 = double_to_fixed64(1.0);
}

void CellMath::initFixed128() {
    F128_PI = double_to_fixed128(3.14159265358979323846);
    F128_HALF_PI = double_to_fixed128(1.57079632679489661923);
    F128_LN2 = double_to_fixed128(0.69314718055994530941);
}

// =============================================================================
// 원시 비트 연산용 매핑 헬퍼 (Raw 정수 연산 호환 목적)
// =============================================================================
int64_t CellMath::to_raw(fixed64_t a) {
    return ((int64_t)a.i << 32) | (a.f & 0xFFFFFFFFULL);
}

fixed64_t CellMath::from_raw(int64_t raw) {
    fixed64_t a;
    a.i = (int32_t)(raw >> 32);
    a.f = (uint32_t)(raw & 0xFFFFFFFFULL);
    return a;
}

// =============================================================================
// 1. Q32.32 (64비트 고정소수점) 세부 구현부
// =============================================================================
fixed64_t CellMath::double_to_fixed64(double val) {
    fixed64_t res;
    double int_part;
    double frac_part = modf(val, &int_part);
    
    // 🔥 2의 보수 부호 처리: 음수 소수부는 정수부에서 -1을 빌려와 양수로 변환
    if (frac_part < 0.0) {
        int_part -= 1.0;
        frac_part += 1.0;
    }
    
    res.i = (int32_t)int_part;
    res.f = (uint32_t)(frac_part * 4294967296.0 + 0.5);
    return res;
}

double CellMath::fixed64_to_double(fixed64_t f) {
    // 🔥 2의 보수를 실수로 변환할 때는 부호 판단 없이 그대로 더하면 완벽히 복원됨!
    return (double)f.i + ((double)f.f / 4294967296.0);
}

char CellMath::fixed64_polarity(fixed64_t value) {
    if (value.i > 0 || (value.i == 0 && value.f > 0)) return 1;
    if (value.i < 0) return -1;
    return 0;
}

int CellMath::fixed64_cmp(fixed64_t a, fixed64_t b) {
    int64_t ra = to_raw(a);
    int64_t rb = to_raw(b);
    if (ra > rb) return 1;
    if (ra < rb) return -1;
    return 0;
}

fixed64_t CellMath::fixed64_add(fixed64_t a, fixed64_t b) { return from_raw(to_raw(a) + to_raw(b)); }
fixed64_t CellMath::fixed64_sub(fixed64_t a, fixed64_t b) { return from_raw(to_raw(a) - to_raw(b)); }

fixed64_t CellMath::fixed64_mul(fixed64_t a, fixed64_t b) {
    __int128_t res = (__int128_t)to_raw(a) * to_raw(b);
    return from_raw((int64_t)(res >> 32));
}

fixed64_t CellMath::fixed64_div(fixed64_t a, fixed64_t b) {
    int64_t rb = to_raw(b);
    if (rb == 0) return from_raw(0);
    __int128_t num = (__int128_t)to_raw(a) << 32;
    return from_raw((int64_t)(num / rb));
}

fixed64_t CellMath::fixed64_calculate(fixed64_t a, fixed64_t b, char op) {
    switch (op) {
        case '+': return fixed64_add(a, b);
        case '-': return fixed64_sub(a, b);
        case '*': return fixed64_mul(a, b);
        case '/': return fixed64_div(a, b);
        default:  return from_raw(0);
    }
}

fixed64_t CellMath::fixed64_sin(fixed64_t x) { return double_to_fixed64(sin(fixed64_to_double(x))); }
fixed64_t CellMath::fixed64_cos(fixed64_t x) { return double_to_fixed64(cos(fixed64_to_double(x))); }

// =============================================================================
// 2. Q64.64 (128비트 고정소수점) 세부 구현부
// =============================================================================
char CellMath::fixed128_polarity(fixed128_t value) {
    if (value.i > 0 || (value.i == 0 && value.f > 0)) return 1;
    if (value.i < 0) return -1;
    return 0;
}

fixed128_t CellMath::f128_add(fixed128_t a, fixed128_t b) {
    fixed128_t res;
    res.f = a.f + b.f;
    res.i = a.i + b.i + (res.f < a.f ? 1 : 0);
    return res;
}

fixed128_t CellMath::f128_sub(fixed128_t a, fixed128_t b) {
    fixed128_t res;
    res.i = a.i - b.i - (a.f < b.f ? 1 : 0);
    res.f = a.f - b.f;
    return res;
}

fixed128_t CellMath::f128_mul(fixed128_t a, fixed128_t b) {
    __int128_t raw_a = ((__int128_t)a.i << 64) | a.f;
    __int128_t raw_b = ((__int128_t)b.i << 64) | b.f;
    __int128_t upper = raw_a >> 32;
    __int128_t lower = raw_b >> 32;
    __int128_t mid = upper * lower;
    fixed128_t res;
    res.i = (int64_t)(mid >> 64);
    res.f = (uint64_t)mid;
    return res;
}

fixed128_t CellMath::f128_div(fixed128_t a, fixed128_t b) {
    fixed128_t res = {0, 0};
    if (b.i == 0 && b.f == 0) return res;
    return double_to_fixed128(fixed128_to_double(a) / fixed128_to_double(b));
}

fixed128_t CellMath::f128_sqrt(fixed128_t a) { return double_to_fixed128(sqrt(fixed128_to_double(a))); }
fixed128_t CellMath::f128_pow(fixed128_t base, int32_t exp) { return double_to_fixed128(pow(fixed128_to_double(base), exp)); }

fixed128_t CellMath::double_to_fixed128(double d) {
    fixed128_t res;
    double int_part;
    double frac_part = modf(d, &int_part);
    
    // 🔥 2의 보수 부호 처리 적용
    if (frac_part < 0.0) {
        int_part -= 1.0;
        frac_part += 1.0;
    }
    
    res.i = (int64_t)int_part;
    res.f = (uint64_t)(frac_part * 18446744073709551616.0);
    return res;
}

double CellMath::fixed128_to_double(fixed128_t a) {
    return (double)a.i + ((double)a.f / 18446744073709551616.0);
}

fixed128_t CellMath::float128_to_fixed128(__float128 q) { return double_to_fixed128((double)q); }
__float128 CellMath::fixed128_to_float128(fixed128_t a) { return (__float128)fixed128_to_double(a); }
fixed128_t CellMath::f128_sin(fixed128_t x) { return double_to_fixed128(sin(fixed128_to_double(x))); }
fixed128_t CellMath::f128_cos(fixed128_t x) { return double_to_fixed128(cos(fixed128_to_double(x))); }
fixed128_t CellMath::f128_ln(fixed128_t x) { return double_to_fixed128(log(fixed128_to_double(x))); }

// =============================================================================
// 3. Q16.16 (32비트 고정소수점) 세부 구현부
// =============================================================================
int32_t CellMath::fixed32_to_int32(fixed32_t a) { return ((int32_t)a.i << 16) | (a.f & 0xFFFF); }

fixed32_t CellMath::int32_to_fixed32(int32_t a) {
    fixed32_t res;
    res.i = (int16_t)(a >> 16);
    res.f = (uint16_t)(a & 0xFFFF);
    return res;
}

fixed32_t CellMath::fixed32_add(fixed32_t a, fixed32_t b) { return int32_to_fixed32(fixed32_to_int32(a) + fixed32_to_int32(b)); }
fixed32_t CellMath::fixed32_sub(fixed32_t a, fixed32_t b) { return int32_to_fixed32(fixed32_to_int32(a) - fixed32_to_int32(b)); }
fixed32_t CellMath::fixed32_mul(fixed32_t a, fixed32_t b) {
    int64_t res = (int64_t)fixed32_to_int32(a) * fixed32_to_int32(b);
    return int32_to_fixed32((int32_t)(res >> 16));
}
fixed32_t CellMath::fixed32_div(fixed32_t a, fixed32_t b) {
    int32_t rb = fixed32_to_int32(b);
    if (rb == 0) return int32_to_fixed32(0);
    int64_t num = (int64_t)fixed32_to_int32(a) << 16;
    return int32_to_fixed32((int32_t)(num / rb));
}

fixed32_t CellMath::Double_to_fixed32(double d) {
    fixed32_t res;
    double int_part;
    double frac_part = modf(d, &int_part);
    
    // 🔥 2의 보수 부호 처리 적용
    if (frac_part < 0.0) {
        int_part -= 1.0;
        frac_part += 1.0;
    }
    
    res.i = (int16_t)int_part;
    res.f = (uint16_t)(frac_part * 65536.0 + 0.5);
    return res;
}

double CellMath::Fixed32_to_double(fixed32_t f32) {
    return (double)f32.i + ((double)f32.f / 65536.0);
}

// =============================================================================
// 4. Q8.8 (16비트 고정소수점) 및 다중 타입 변환 구현부
// =============================================================================
int16_t CellMath::fixed16_to_int16(fixed16_t a) { return ((int16_t)a.i << 8) | (a.f & 0xFF); }

fixed16_t CellMath::int16_to_fixed16(int16_t a) {
    fixed16_t res;
    res.i = (char)(a >> 8);
    res.f = (uint8_t)(a & 0xFF);
    return res;
}

fixed16_t CellMath::fixed16_add(fixed16_t a, fixed16_t b) { return int16_to_fixed16(fixed16_to_int16(a) + fixed16_to_int16(b)); }
fixed16_t CellMath::fixed16_sub(fixed16_t a, fixed16_t b) { return int16_to_fixed16(fixed16_to_int16(a) - fixed16_to_int16(b)); }
fixed16_t CellMath::fixed16_mul(fixed16_t a, fixed16_t b) {
    int32_t res = (int32_t)fixed16_to_int16(a) * fixed16_to_int16(b);
    return int16_to_fixed16((int16_t)(res >> 8));
}
fixed16_t CellMath::fixed16_div(fixed16_t a, fixed16_t b) {
    int16_t rb = fixed16_to_int16(b);
    if (rb == 0) return int16_to_fixed16(0);
    int32_t num = (int32_t)fixed16_to_int16(a) << 8;
    return int16_to_fixed16((int16_t)(num / rb));
}

fixed16_t CellMath::float_to_fixed16(float f_val) {
    fixed16_t res;
    float int_part;
    float frac_part = modff(f_val, &int_part);
    
    // 🔥 2의 보수 부호 처리 적용
    if (frac_part < 0.0f) {
        int_part -= 1.0f;
        frac_part += 1.0f;
    }
    
    res.i = (char)int_part;
    res.f = (uint8_t)(frac_part * 256.0f + 0.5f);
    return res;
}

float CellMath::fixed16_to_float(fixed16_t a) {
    return (float)a.i + ((float)a.f / 256.0f);
}

fixed32_t CellMath::float_to_fixed32(float f_val) { return Double_to_fixed32((double)f_val); }
float CellMath::fixed32_to_float(fixed32_t a) { return (float)Fixed32_to_double(a); }
fixed64_t CellMath::fixed16_to_fixed64(fixed16_t a) { return double_to_fixed64((double)fixed16_to_float(a)); }

// =============================================================================
// 5. 의미망 고유 유틸리티 및 학습 모델 알고리즘 구현부
// =============================================================================
fixed64_t CellMath::fixed64_hebbian_update(fixed64_t current_weight, fixed64_t input, fixed64_t output, fixed64_t eta) {
    fixed64_t delta = fixed64_mul(eta, fixed64_mul(input, output));
    return fixed64_add(current_weight, delta);
}

fixed64_t CellMath::fixed64_oja_update(fixed64_t current_weight, fixed64_t input, fixed64_t output, fixed64_t eta) {
    fixed64_t y2 = fixed64_mul(output, output);
    fixed64_t w_y2 = fixed64_mul(current_weight, y2);
    fixed64_t x_y = fixed64_mul(input, output);
    fixed64_t delta = fixed64_mul(eta, fixed64_sub(x_y, w_y2));
    return fixed64_add(current_weight, delta);
}

int128 CellMath::extended_gcd_128(int128 a, int128 b, int128 *x, int128 *y) {
    if (b == 0) {
        *x = 1;
        *y = 0;
        return a;
    }
    int128 x1, y1;
    int128 gcd = extended_gcd_128(b, a % b, &x1, &y1);
    *x = y1;
    *y = x1 - (a / b) * y1;
    return gcd;
}

int64_t CellMath::fixed_point_mul(int64_t a, int64_t b) {
    return (int64_t)(((__int128_t)a * b) >> 32);
}

int CellMath::solve_fixed_point_combination(int64_t input_values[256], int64_t target_value, int64_t output_factors[256]) {
    for (int i = 0; i < 256; ++i) {
        if (input_values[i] != 0) {
            output_factors[i] = (target_value << 32) / input_values[i];
            for (int j = i + 1; j < 256; ++j) output_factors[j] = 0;
            return 1;
        }
    }
    return 0;
}

int CellMath::solve_approx_fixed_point(int64_t inputs[256], int64_t target, int64_t factors[256]) {
    int64_t sum_inputs = 0;
    for (int i = 0; i < 256; ++i) sum_inputs += inputs[i];
    if (sum_inputs == 0) return 0;
    int64_t common_factor = (target << 32) / sum_inputs;
    for (int i = 0; i < 256; ++i) factors[i] = common_factor;
    return 1;
}

void CellMath::apply_oja_rule_with_relu(float* inputs, float* weights, int size, float learning_rate, float* output_ptr) {
    float sum = 0.0f;
    for (int i = 0; i < size; ++i) sum += inputs[i] * weights[i];
    float output = (sum > 0.0f) ? sum : 0.0f;
    *output_ptr = output;
    for (int i = 0; i < size; ++i) {
        weights[i] += learning_rate * output * (inputs[i] - output * weights[i]);
    }
}

char CellMath::getPositionOfBitSet(uint8_t byte, uint32_t* buffer, uint32_t offset) {
    char count = 0;
    for (int i = 0; i < 8; ++i) {
        if ((byte & (0x80 >> i)) != 0) {
            buffer[count++] = offset + i;
        }
    }
    return count;
}

fixed64_t CellMath::get_adaptive_threshold_fixed(fixed64_t* inputs, int size, fixed64_t sensitivity) {
    if (size <= 0) return from_raw(0);
    int64_t sum = 0;
    for (int i = 0; i < size; ++i) sum += to_raw(inputs[i]);
    int64_t avg = sum / size;
    return from_raw(fixed_mul(avg, to_raw(sensitivity)));
}