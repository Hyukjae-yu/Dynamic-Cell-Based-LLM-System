#include "main.hpp"
#include "test.hpp" // 🔥 분리된 테스트 모듈 헤더 추가
#include <stdio.h>
#include <sys/stat.h>
#include <string>
#include <filesystem>

#ifndef MASTER_FILE_PATH
#define MASTER_FILE_PATH "./.system/system.bin"
#endif

// =============================================================================
// 시스템 부팅 및 종료
// =============================================================================
bool OfflineMinji::bootUpSystem() {
    printf("[System] 마스터 스토리지(가상 메모리) 초기화 시작...\n");
    struct stat st = {0};
    bool isNewFile = (stat(MASTER_FILE_PATH, &st) != 0 || st.st_size == 0);
    
    if (!storage.initializeMasterFile(MASTER_FILE_PATH)) return false;
    
    sysManager.autoFormatCells(storage, isNewFile);

    CellMath::initFixed16();
    CellMath::initFixed32();
    CellMath::initFixed64();
    CellMath::initFixed128();
    return true;
}

void OfflineMinji::shutDownSystem() {
    storage.shutDown();
    printf("[System] 가상 메모리 관리자 종료 완료.\n");
}

// =============================================================================
// 메인 마스터 진입점
// =============================================================================
int main() {
    namespace fs = std::filesystem;
    std::string saveDir = ".system/autoLearn";

    printf("\033[2J\033[1;1H");
    OfflineMinji minji;

    if (!fs::exists(saveDir)) {
        fs::create_directories(saveDir);
        printf("[System] 📁 '%s' 폴더가 없어 새로 생성했습니다.\n", saveDir.c_str());
    }

    printf("==========================================\n");
    printf("[System] 오프라인 민지 시스템 부팅 시도...\n");
    printf("==========================================\n");

    if (minji.bootUpSystem()) {
        printf("\n[System] 부팅 대성공! 가상 메모리 로드 완료.\n");
        
        // 🔥 아주 깔끔해진 테스트 호출부!
        SystemTester::runAllTests(minji);
        
    } else {
        printf("\n[Error] 부팅 실패.\n\n");
    }

    minji.shutDownSystem();
    printf("[System] 시스템이 안전하게 종료되었습니다.\n");
    
    return 0;
}