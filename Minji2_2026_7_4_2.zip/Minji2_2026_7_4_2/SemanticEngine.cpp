#include "SemanticEngine.hpp"
#include <stdio.h>
#include <string.h>

uint32_t SemanticEngine::getOrCreateNode(BrainNetworkEngine::Cell* pool, size_t poolSize, const char* alias) {
    if (!pool || !alias) return 0xFFFFFFFF;

    // 1. 이미 존재하는지 검색
    for (size_t i = 0; i < poolSize; ++i) {
        if (strncmp(pool[i].getAlias(), alias, 64) == 0) {
            return pool[i].getID();
        }
    }

    // 2. 없으면 빈 셀(Alias가 없는 셀)을 찾아 새로 할당
    for (size_t i = 0; i < poolSize; ++i) {
        if (pool[i].getAlias()[0] == '\0') {
            pool[i].initCell((uint32_t)i);
            pool[i].setAlias(alias);
            // 기본 스레시홀드 설정 (예: 1.0)
            pool[i].setPThreshold({1, 0});
            return (uint32_t)i;
        }
    }
    return 0xFFFFFFFF; // 메모리 풀 가득 참
}

bool SemanticEngine::linkFactRelation(BrainNetworkEngine::Cell* pool, size_t poolSize, 
                                      BrainNetworkEngine::CellConn* connPool, size_t connPoolSize,
                                      const char* subject, const char* object, fixed64_t weight) {
    
    uint32_t sID = getOrCreateNode(pool, poolSize, subject);
    uint32_t tID = getOrCreateNode(pool, poolSize, object);

    if (sID == 0xFFFFFFFF || tID == 0xFFFFFFFF) return false;

    // FUNC_FACT_RELATION (사실 기반 연결) 코드로 연결
    return pool[sID].addConnection(connPool, connPoolSize, sID, tID, weight, FUNC_FACT_RELATION);
}

void SemanticEngine::resetNetworkEnergy(BrainNetworkEngine::Cell* pool, size_t poolSize) {
    if (!pool) return;
    for (size_t i = 0; i < poolSize; ++i) {
        pool[i].setEnergy({0, 0});
    }
}

void SemanticEngine::printFiredNodes(BrainNetworkEngine::Cell* pool, size_t poolSize) {
    if (!pool) return;
    printf("[System] 현재 발화된 활성 노드 목록:\n");
    bool found = false;
    for (size_t i = 0; i < poolSize; ++i) {
        if (pool[i].getAlias()[0] != '\0' && pool[i].isOverPThreshold()) {
            double e_val = CellMath::fixed64_to_double(pool[i].getEnergy());
            printf("  -> ID: %u | Alias: '%s' | Energy: %.4f\n", pool[i].getID(), pool[i].getAlias(), e_val);
            found = true;
        }
    }
    if (!found) printf("  -> (발화된 노드가 없습니다.)\n");
}