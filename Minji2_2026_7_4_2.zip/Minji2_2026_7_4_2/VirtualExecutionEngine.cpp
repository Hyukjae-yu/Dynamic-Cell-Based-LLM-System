#include "VirtualExecutionEngine.hpp"
#include <stdio.h>
#include <string.h>

VirtualExecutionEngine::VirtualExecutionEngine() {
    for (int i = 0; i < MAX_SCRIPT_TRIGGERS; ++i) {
        registry[i].reset();
    }
}

VirtualExecutionEngine::~VirtualExecutionEngine() {}

bool VirtualExecutionEngine::bindScriptToCell(uint32_t cellID, const char* dummyPath) {
    for (int i = 0; i < MAX_SCRIPT_TRIGGERS; ++i) {
        if (!registry[i].getIsRegistered()) {
            registry[i].setCellID(cellID);
            registry[i].setIsRegistered(true);
            
            // 테스트용 임시 기본 명령 주입 (vCPU 가동 증명용)
            registry[i].setBasicCmd(0, 0xAAAA0001); 
            registry[i].setExtBlockHead(0xFFFFFFFF); // 일단 확장 없음
            return true;
        }
    }
    return false;
}

bool VirtualExecutionEngine::unbindScriptFromCell(uint32_t cellID) {
    for (int i = 0; i < MAX_SCRIPT_TRIGGERS; ++i) {
        if (registry[i].getIsRegistered() && registry[i].getCellID() == cellID) {
            registry[i].reset();
            return true;
        }
    }
    return false;
}

// 🔥 오빠가 말한 핵심: 기본 내장 버퍼 실행 후 확장 영역 점프 및 연속 실행 시뮬레이터
void VirtualExecutionEngine::executeVcpuChain(const ExecutionContext& context, ExecBlock* blockPool, uint32_t blockPoolSize) {
    printf("[vCPU::Engine] ⚡ 내장 vCPU 코어 기본 명령 블록(32bit x 4) 실행 완료:\n");
    printf("  -> [Basic CMDs] 0x%08X 0x%08X 0x%08X 0x%08X\n", 
           context.getBasicCmd(0), context.getBasicCmd(1), context.getBasicCmd(2), context.getBasicCmd(3));

    uint32_t nextBlockIdx = context.getExtBlockHead();
    
    // 부족하면 신설된 오프셋 아이디 값을 받아 뒷쪽 확장 메모리 영역으로 점프!
    if (nextBlockIdx != 0xFFFFFFFF) {
        printf("[vCPU::Jump] ➡️ 대용량 코드 감지: 확장 메모리 번지 [ID: %u]로 점프합니다.\n", nextBlockIdx);
        
        while (nextBlockIdx != 0xFFFFFFFF && nextBlockIdx < blockPoolSize) {
            const ExecBlock& currentBlock = blockPool[nextBlockIdx];
            printf("  -> [ExtBlock ID: %u] Execution: 0x%08X 0x%08X 0x%08X 0x%08X\n", 
                   nextBlockIdx, currentBlock.getCmd(0), currentBlock.getCmd(1), currentBlock.getCmd(2), currentBlock.getCmd(3));
            
            // 기차 칸처럼 줄줄이 체인 타고 다음 블록으로 이동
            nextBlockIdx = currentBlock.getToNext(); 
        }
        printf("[vCPU::Chain] 🏆 확장 블록 체인 엔드 도달. 전체 대용량 스크립트 실행 대성공.\n");
    }
}

void VirtualExecutionEngine::scanAndTriggerScripts(BrainNetworkEngine::Cell* cellPool, size_t poolSize, ExecBlock* blockPool, uint32_t blockPoolSize) {
    if (!cellPool || !blockPool) return;
    for (int i = 0; i < MAX_SCRIPT_TRIGGERS; ++i) {
        if (registry[i].getIsRegistered()) {
            uint32_t cID = registry[i].getCellID();
            if (cID < poolSize && cellPool[cID].isOverPThreshold() && cellPool[cID].isExec()) {
                printf("\n[vCPU::Interrupt] 인터럽트 발화 주체 Cell ID: %u ('%s')\n", cID, cellPool[cID].getAlias());
                executeVcpuChain(registry[i], blockPool, blockPoolSize);
            }
        }
    }
}

bool VirtualExecutionEngine::setExtBlockHeadForCell(uint32_t cellID, uint32_t headIdx) {
    for (int i = 0; i < MAX_SCRIPT_TRIGGERS; ++i) {
        if (registry[i].getIsRegistered() && registry[i].getCellID() == cellID) {
            registry[i].setExtBlockHead(headIdx);
            return true;
        }
    }
    return false;
}