#include "BrainNetworkEngine.hpp"
#include <string.h> 
#include <stdlib.h> 
#include <stdio.h> 

// =============================================================================
// [BrainNetworkEngine::Cell] 기본 I/O 및 신규 속성
// =============================================================================
void BrainNetworkEngine::Cell::initCell(uint32_t newID) {
    this->id = newID;
    this->connOffset = 0xFFFFFFFF;
    this->energy = {0, 0};
    this->pThreshold = {0, 0};
    this->nThreshold = {0, 0};
    memset(this->alias, 0, sizeof(this->alias));
    this->activeFlag = false;
    this->execFlag = false; 
    memset(this->reserved, 0, sizeof(this->reserved));
}

void BrainNetworkEngine::Cell::setID(uint32_t newID) { this->id = newID; }
uint32_t BrainNetworkEngine::Cell::getID() const { return this->id; }
uint64_t BrainNetworkEngine::Cell::getConnOffset() const { return this->connOffset; }
void BrainNetworkEngine::Cell::setConnOffset(uint64_t offset) { this->connOffset = offset; }

void BrainNetworkEngine::Cell::setAlias(const char* name) {
    if (!name) return;
    strncpy(this->alias, name, 63);
    this->alias[63] = '\0';
}
const char* BrainNetworkEngine::Cell::getAlias() const { return this->alias; }
void BrainNetworkEngine::Cell::setActive(bool flag) { this->activeFlag = flag; }
bool BrainNetworkEngine::Cell::isActive() const { return this->activeFlag; }
void BrainNetworkEngine::Cell::toggleActive() { this->activeFlag = !this->activeFlag; }

void BrainNetworkEngine::Cell::setExecFlag(bool flag) { this->execFlag = flag; }
bool BrainNetworkEngine::Cell::isExec() const { return this->execFlag; }

void BrainNetworkEngine::Cell::setEnergy(fixed64_t e) { this->energy = e; }
fixed64_t BrainNetworkEngine::Cell::getEnergy() const { return this->energy; }
void BrainNetworkEngine::Cell::addEnergy(fixed64_t e) { this->energy = CellMath::fixed64_add(this->energy, e); }
void BrainNetworkEngine::Cell::subEnergy(fixed64_t e) { this->energy = CellMath::fixed64_sub(this->energy, e); }

void BrainNetworkEngine::Cell::setPThreshold(fixed64_t p) { this->pThreshold = p; }
fixed64_t BrainNetworkEngine::Cell::getPThreshold() const { return this->pThreshold; }
void BrainNetworkEngine::Cell::setNThreshold(fixed64_t n) { this->nThreshold = n; }
fixed64_t BrainNetworkEngine::Cell::getNThreshold() const { return this->nThreshold; }

bool BrainNetworkEngine::Cell::isOverPThreshold() const {
    return (this->energy.i > this->pThreshold.i) || 
           (this->energy.i == this->pThreshold.i && this->energy.f >= this->pThreshold.f);
}

bool BrainNetworkEngine::Cell::isUnderNThreshold() const {
    return (this->energy.i < this->nThreshold.i) || 
           (this->energy.i == this->nThreshold.i && this->energy.f <= this->nThreshold.f);
}

// =============================================================================
// [BrainNetworkEngine::Cell] 체인 관리 로직
// =============================================================================
int32_t BrainNetworkEngine::Cell::findConnection(CellConn* connPool, uint32_t targetID, int* outSlot) const {
    if (this->connOffset == 0xFFFFFFFF) return NOCONN;

    int32_t currentChunk = (int32_t)this->connOffset;
    while (currentChunk != NOCONN) {
        int slot = connPool[currentChunk].findTarget(targetID);
        if (slot != -1) {
            if (outSlot) *outSlot = slot;
            return currentChunk; 
        }
        currentChunk = connPool[currentChunk].getNextChunk();
    }
    return NOCONN;
}

bool BrainNetworkEngine::Cell::addConnection(CellConn* connPool, size_t connPoolSize, uint32_t sID, uint32_t tID, fixed64_t w, uint8_t assoc) {
    if (this->connOffset == 0xFFFFFFFF) {
        int32_t freeChunk = BrainNetworkEngine::findFreeConnChunk(connPool, connPoolSize);
        if (freeChunk == NOCONN) return false;
        
        this->connOffset = freeChunk;
        return connPool[freeChunk].connect(connPool[freeChunk].findEmptySlot(), sID, tID, w, assoc);
    }

    int32_t currentChunk = (int32_t)this->connOffset;
    int32_t lastChunk = currentChunk;

    while (currentChunk != NOCONN) {
        if (connPool[currentChunk].findTarget(tID) != -1) return true; 
        
        int slot = connPool[currentChunk].findEmptySlot();
        if (slot != -1) {
            return connPool[currentChunk].connect(slot, sID, tID, w, assoc);
        }
        lastChunk = currentChunk;
        currentChunk = connPool[currentChunk].getNextChunk();
    }

    int32_t newChunk = BrainNetworkEngine::findFreeConnChunk(connPool, connPoolSize);
    if (newChunk == NOCONN) return false;

    connPool[lastChunk].setNextChunk(newChunk);
    connPool[newChunk].setPrevChunk(lastChunk);
    
    return connPool[newChunk].connect(connPool[newChunk].findEmptySlot(), sID, tID, w, assoc);
}

bool BrainNetworkEngine::Cell::removeConnection(CellConn* connPool, uint32_t targetID) {
    int slot;
    int32_t chunkIdx = findConnection(connPool, targetID, &slot);
    if (chunkIdx != NOCONN) {
        connPool[chunkIdx].disconnect(slot);
        return true;
    }
    return false;
}

fixed64_t BrainNetworkEngine::Cell::getWeightTo(CellConn* connPool, uint32_t targetID) const {
    int slot;
    int32_t chunkIdx = findConnection(connPool, targetID, &slot);
    if (chunkIdx != NOCONN) {
        return connPool[chunkIdx].getWeight(slot);
    }
    return {0, 0};
}

bool BrainNetworkEngine::Cell::addConnectionByAlias(Cell* cellPool, size_t cellPoolSize, CellConn* connPool, size_t connPoolSize, uint32_t sID, const char* targetAlias, fixed64_t w, uint8_t assoc) {
    uint32_t tID = BrainNetworkEngine::findIDByAlias(cellPool, cellPoolSize, targetAlias);
    if (tID == 0xFFFFFFFF) return false;
    return addConnection(connPool, connPoolSize, sID, tID, w, assoc);
}

bool BrainNetworkEngine::Cell::isConnectedToAlias(Cell* cellPool, size_t cellPoolSize, CellConn* connPool, const char* targetAlias) const {
    uint32_t tID = BrainNetworkEngine::findIDByAlias(cellPool, cellPoolSize, targetAlias);
    if (tID == 0xFFFFFFFF) return false;
    int slot;
    return (findConnection(connPool, tID, &slot) != NOCONN);
}

// =============================================================================
// [BrainNetworkEngine::CellConn] 멤버 함수 구현부
// =============================================================================
void BrainNetworkEngine::CellConn::reset() {
    for (int i = 0; i < MAX_CONN_A_UNIT; ++i) {
        sourceID[i] = 0xFFFFFFFF; 
        targetID[i] = 0xFFFFFFFF; 
        weight[i] = {0, 0}; 
        association[i] = 0;
    }
    toPrevious = NOCONN; 
    toNext = NOCONN;
    tokenFlag = false;
    memset(reserved, 0, sizeof(reserved));
}

bool BrainNetworkEngine::CellConn::isFull() const { return (findEmptySlot() == -1); }
bool BrainNetworkEngine::CellConn::isEmpty() const {
    for (int i = 0; i < MAX_CONN_A_UNIT; ++i) { 
        if (targetID[i] != 0xFFFFFFFF) return false; 
    }
    return true;
}
int BrainNetworkEngine::CellConn::getUsedCount() const {
    int count = 0;
    for (int i = 0; i < MAX_CONN_A_UNIT; ++i) { if (targetID[i] != 0xFFFFFFFF) count++; }
    return count;
}
int BrainNetworkEngine::CellConn::findEmptySlot() const {
    for (int i = 0; i < MAX_CONN_A_UNIT; ++i) { if (targetID[i] == 0xFFFFFFFF) return i; }
    return -1; 
}
int BrainNetworkEngine::CellConn::findTarget(uint32_t tID) const {
    for (int i = 0; i < MAX_CONN_A_UNIT; ++i) { if (targetID[i] == tID) return i; }
    return -1;
}

bool BrainNetworkEngine::CellConn::connect(int slot, uint32_t sID, uint32_t tID, fixed64_t w, uint8_t assoc) {
    if (slot < 0 || slot >= MAX_CONN_A_UNIT) return false;
    sourceID[slot] = sID; targetID[slot] = tID; weight[slot] = w; association[slot] = assoc;
    return true;
}

void BrainNetworkEngine::CellConn::disconnect(int slot) {
    if (slot >= 0 && slot < MAX_CONN_A_UNIT) {
        sourceID[slot] = 0xFFFFFFFF; targetID[slot] = 0xFFFFFFFF; weight[slot] = {0, 0}; association[slot] = 0;
    }
}

uint32_t BrainNetworkEngine::CellConn::getSourceID(int slot) const { return (slot >= 0 && slot < MAX_CONN_A_UNIT) ? sourceID[slot] : 0xFFFFFFFF; }
uint32_t BrainNetworkEngine::CellConn::getTargetID(int slot) const { return (slot >= 0 && slot < MAX_CONN_A_UNIT) ? targetID[slot] : 0xFFFFFFFF; }
uint8_t BrainNetworkEngine::CellConn::getAssociation(int slot) const { return (slot >= 0 && slot < MAX_CONN_A_UNIT) ? association[slot] : 0; }
void BrainNetworkEngine::CellConn::setAssociation(int slot, uint8_t assoc) { if (slot >= 0 && slot < MAX_CONN_A_UNIT) association[slot] = assoc; }

fixed64_t BrainNetworkEngine::CellConn::getWeight(int slot) const { return (slot >= 0 && slot < MAX_CONN_A_UNIT) ? weight[slot] : fixed64_t{0, 0}; }
void BrainNetworkEngine::CellConn::setWeight(int slot, fixed64_t w) { if (slot >= 0 && slot < MAX_CONN_A_UNIT) weight[slot] = w; }
void BrainNetworkEngine::CellConn::addWeight(int slot, fixed64_t w) { if (slot >= 0 && slot < MAX_CONN_A_UNIT) weight[slot] = CellMath::fixed64_add(weight[slot], w); }
void BrainNetworkEngine::CellConn::subWeight(int slot, fixed64_t w) { if (slot >= 0 && slot < MAX_CONN_A_UNIT) weight[slot] = CellMath::fixed64_sub(weight[slot], w); }
void BrainNetworkEngine::CellConn::applyDecay(fixed64_t decayRate) { /* 향후 구현용 */ }

void BrainNetworkEngine::CellConn::setNextChunk(int32_t relativePos) { toNext = relativePos; }
int32_t BrainNetworkEngine::CellConn::getNextChunk() const { return toNext; }
void BrainNetworkEngine::CellConn::setPrevChunk(int32_t relativePos) { toPrevious = relativePos; }
int32_t BrainNetworkEngine::CellConn::getPrevChunk() const { return toPrevious; }
bool BrainNetworkEngine::CellConn::hasNext() const { return (toNext != NOCONN); }
bool BrainNetworkEngine::CellConn::hasPrev() const { return (toPrevious != NOCONN); }

// =============================================================================
// [BrainNetworkEngine] 글로벌 스캔 / 유틸리티 / 망 생성기
// =============================================================================
BrainNetworkEngine::BrainNetworkEngine() {}
BrainNetworkEngine::~BrainNetworkEngine() {}

uint32_t BrainNetworkEngine::findIDByAlias(Cell* pool, size_t poolSize, const char* name) {
    if (!pool || !name) return 0xFFFFFFFF;
    for (size_t i = 0; i < poolSize; ++i) {
        if (strncmp(pool[i].getAlias(), name, 64) == 0) return pool[i].getID();
    }
    return 0xFFFFFFFF;
}

bool BrainNetworkEngine::fireCellByAlias(Cell* pool, size_t poolSize, const char* name) {
    uint32_t id = findIDByAlias(pool, poolSize, name);
    if (id != 0xFFFFFFFF) { pool[id].setActive(true); return true; }
    return false;
}

bool BrainNetworkEngine::toggleCellByAlias(Cell* pool, size_t poolSize, const char* name) {
    uint32_t id = findIDByAlias(pool, poolSize, name);
    if (id != 0xFFFFFFFF) { pool[id].toggleActive(); return true; }
    return false;
}

void BrainNetworkEngine::clearAllActiveFlags(Cell* pool, size_t poolSize) {
    if (!pool) return;
    for (size_t i = 0; i < poolSize; ++i) pool[i].setActive(false);
}

int32_t BrainNetworkEngine::findFreeConnChunk(CellConn* connPool, size_t connPoolSize) {
    if (!connPool) return NOCONN;
    for (size_t i = 0; i < connPoolSize; ++i) {
        if (connPool[i].isEmpty() && !connPool[i].hasPrev() && !connPool[i].hasNext()) {
            return (int32_t)i;
        }
    }
    return NOCONN; 
}

bool BrainNetworkEngine::buildDenseNetwork(Cell* cellPool, size_t cellPoolSize, CellConn* connPool, size_t connPoolSize, 
                                           uint32_t startID, const uint32_t* layerSizes, int layerCount, fixed64_t w_init, bool initRandom) {
    if (!cellPool || !connPool || !layerSizes || layerCount < 2) return false;

    uint32_t totalCellsNeeded = 0;
    for (int i = 0; i < layerCount; ++i) {
        totalCellsNeeded += layerSizes[i];
    }
    if (startID + totalCellsNeeded > cellPoolSize) return false; 

    for (uint32_t i = 0; i < totalCellsNeeded; ++i) {
        cellPool[startID + i].initCell(startID + i);
    }

    uint32_t currentLayerStart = startID;
    
    for (int i = 0; i < layerCount - 1; ++i) {
        uint32_t nextLayerStart = currentLayerStart + layerSizes[i];
        
        for (uint32_t src = 0; src < layerSizes[i]; ++src) {
            uint32_t sID = currentLayerStart + src;
            
            for (uint32_t tgt = 0; tgt < layerSizes[i + 1]; ++tgt) {
                uint32_t tID = nextLayerStart + tgt;
                
                fixed64_t w = w_init;
                if (initRandom) {
                    double random_w = ((double)rand() / RAND_MAX) * 2.0 - 1.0; 
                    w = CellMath::double_to_fixed64(random_w);
                }
                
                cellPool[sID].addConnection(connPool, connPoolSize, sID, tID, w, 0);
            }
        }
        currentLayerStart = nextLayerStart;
    }
    return true;
}

// 🔥 자동 학습기
bool BrainNetworkEngine::autoTrainBlockLayer(
    Cell* pool, size_t poolSize, CellConn* connPool, size_t connPoolSize,
    uint32_t startID, const uint32_t* layers, size_t layerCount,
    fixed64_t* trainingData, fixed64_t* targetData, size_t dataCount,
    fixed64_t learningRate, int maxEpochs, fixed64_t targetErrorLimit,
    const char* saveFileName)
{
    if (!pool || !connPool || layerCount < 2) return false;

    uint32_t inputSize = layers[0];
    uint32_t outputSize = layers[layerCount - 1];
    
    uint32_t totalCells = 0;
    for (size_t i = 0; i < layerCount; ++i) {
        totalCells += layers[i];
    }

    double* nodeDeltas = new double[totalCells];

    printf("\n[AutoTrain] 🧠 자동 학습 개시 (역전파 알고리즘 가동 | Epochs: %d)\n", maxEpochs);

    for (int epoch = 1; epoch <= maxEpochs; ++epoch) {
        bool allPassed = true;
        double maxErrorInEpoch = 0.0;

        for (size_t d = 0; d < dataCount; ++d) {
            
            for (uint32_t i = 0; i < totalCells; ++i) pool[startID + i].setEnergy({0, 0});
            for (uint32_t i = 0; i < inputSize; ++i) pool[startID + i].setEnergy(trainingData[d * inputSize + i]);

            uint32_t currentLayerOffset = 0;
            for (size_t l = 0; l < layerCount - 1; ++l) {
                uint32_t curLayerSize = layers[l];
                uint32_t nextLayerSize = layers[l + 1];
                uint32_t nextLayerOffset = currentLayerOffset + curLayerSize;

                for (uint32_t i = 0; i < curLayerSize; ++i) {
                    uint32_t sourceID = startID + currentLayerOffset + i;
                    double f_sEnergy = CellMath::fixed64_to_double(pool[sourceID].getEnergy());
                    
                    if (f_sEnergy > 1.0) f_sEnergy = 1.0;
                    if (f_sEnergy < 0.0) f_sEnergy = 0.0;
                    pool[sourceID].setEnergy(CellMath::double_to_fixed64(f_sEnergy));

                    if (f_sEnergy > 0.0) {
                        for (uint32_t j = 0; j < nextLayerSize; ++j) {
                            uint32_t targetID = startID + nextLayerOffset + j;
                            fixed64_t w = pool[sourceID].getWeightTo(connPool, targetID);
                            double f_w = CellMath::fixed64_to_double(w);
                            double propagated = f_sEnergy * f_w;
                            pool[targetID].addEnergy(CellMath::double_to_fixed64(propagated));
                        }
                    }
                }
                currentLayerOffset = nextLayerOffset;
            }
            
            uint32_t outOffset = totalCells - outputSize;
            for (uint32_t o = 0; o < outputSize; ++o) {
                uint32_t outID = startID + outOffset + o;
                double f_out = CellMath::fixed64_to_double(pool[outID].getEnergy());
                if (f_out > 1.0) f_out = 1.0;
                if (f_out < 0.0) f_out = 0.0;
                pool[outID].setEnergy(CellMath::double_to_fixed64(f_out));
            }

            memset(nodeDeltas, 0, sizeof(double) * totalCells);
            for (uint32_t o = 0; o < outputSize; ++o) {
                uint32_t outID = startID + outOffset + o;
                double f_out = CellMath::fixed64_to_double(pool[outID].getEnergy());
                double f_exp = CellMath::fixed64_to_double(targetData[d * outputSize + o]);
                
                double err = f_exp - f_out;
                
                if (err > maxErrorInEpoch) maxErrorInEpoch = err;
                else if (-err > maxErrorInEpoch) maxErrorInEpoch = -err;
                
                if (maxErrorInEpoch > CellMath::fixed64_to_double(targetErrorLimit)) {
                    allPassed = false;
                }

                double deriv = (f_out > 0.0 && f_out < 1.0) ? 1.0 : 0.2; 
                nodeDeltas[outOffset + o] = err * deriv;
            }

            currentLayerOffset = totalCells - outputSize;
            for (int l = layerCount - 2; l >= 0; --l) {
                uint32_t curSize = layers[l];
                uint32_t nextSize = layers[l + 1];
                uint32_t curOffset = currentLayerOffset - curSize;
                uint32_t nextOffset = currentLayerOffset;

                for (uint32_t i = 0; i < curSize; ++i) {
                    uint32_t sID = startID + curOffset + i;
                    double sumErr = 0.0;
                    
                    for (uint32_t j = 0; j < nextSize; ++j) {
                        uint32_t tID = startID + nextOffset + j;
                        int slot;
                        int32_t chunk = pool[sID].findConnection(connPool, tID, &slot);
                        if (chunk != NOCONN) {
                            double w = CellMath::fixed64_to_double(connPool[chunk].getWeight(slot));
                            sumErr += nodeDeltas[nextOffset + j] * w;
                        }
                    }
                    
                    double f_e = CellMath::fixed64_to_double(pool[sID].getEnergy());
                    double deriv = (f_e > 0.0 && f_e < 1.0) ? 1.0 : 0.2; 
                    nodeDeltas[curOffset + i] = sumErr * deriv;
                }
                currentLayerOffset = curOffset;
            }

            double l_rate = CellMath::fixed64_to_double(learningRate);
            currentLayerOffset = 0;
            
            for (size_t l = 0; l < layerCount - 1; ++l) {
                uint32_t curSize = layers[l];
                uint32_t nextSize = layers[l + 1];
                uint32_t nextOffset = currentLayerOffset + curSize;

                for (uint32_t i = 0; i < curSize; ++i) {
                    uint32_t sID = startID + currentLayerOffset + i;
                    double f_sEnergy = CellMath::fixed64_to_double(pool[sID].getEnergy());
                    
                    if (f_sEnergy > 0) {
                        for (uint32_t j = 0; j < nextSize; ++j) {
                            uint32_t tID = startID + nextOffset + j;
                            int slot;
                            int32_t chunk = pool[sID].findConnection(connPool, tID, &slot);
                            if (chunk != NOCONN) {
                                double cur_w = CellMath::fixed64_to_double(connPool[chunk].getWeight(slot));
                                double deltaW = l_rate * nodeDeltas[nextOffset + j] * f_sEnergy;
                                connPool[chunk].setWeight(slot, CellMath::double_to_fixed64(cur_w + deltaW));
                            }
                        }
                    }
                }
                currentLayerOffset = nextOffset;
            }
        } 

        // 조기 종료 (Early Stopping) 성공 시
        if (allPassed) {
            printf("[AutoTrain] 🏆 성공! Epoch %d 만에 완벽히 각본을 숙지했습니다.\n", epoch);
            
            if (saveFileName != nullptr) {
                char fullPath[256];
                snprintf(fullPath, sizeof(fullPath), ".system/autoLearn/%s", saveFileName);
                
                // 🔥 수정 완료: 오빠가 만든 롬팩(Cartridge) 추출 함수로 변경하고 인자도 맞춤!
                saveBlockWeights(pool, connPool, startID, layers, layerCount, fullPath);
                
                printf("[System] 💾 학습 결과가 '%s'에 안전하게 저장되었습니다.\n", fullPath);
            }
            
            delete[] nodeDeltas;
            return true; 
        }

        if (epoch % 1000 == 0 || epoch == maxEpochs) {
            printf("  -> Epoch %d 진행 중... 현재 최대 오차: %.4f\n", epoch, maxErrorInEpoch);
        }
    }

    printf("[AutoTrain] ⚠️ %d 번 반복했지만 허용 오차 내로 진입하지 못했습니다.\n", maxEpochs);
    delete[] nodeDeltas;
    return false;
}

// 🔥 세이브 & 로드 함수 실제 구현부
bool BrainNetworkEngine::saveBlockWeights(Cell* pool, CellConn* connPool, uint32_t startID, const uint32_t* layers, int layerCount, const char* filepath) {
    FILE* fp = fopen(filepath, "wb");
    if (!fp) return false;

    uint32_t currentLayerOffset = 0;
    // 오빠가 설정한 layer (8x64x64x8) 구조를 따라가며 가중치(fixed64_t)만 쏙쏙 뽑아서 파일에 씁니다!
    for (int l = 0; l < layerCount - 1; ++l) {
        uint32_t curSize = layers[l];
        uint32_t nextSize = layers[l + 1];
        uint32_t nextOffset = currentLayerOffset + curSize;

        for (uint32_t i = 0; i < curSize; ++i) {
            uint32_t sID = startID + currentLayerOffset + i;
            for (uint32_t j = 0; j < nextSize; ++j) {
                uint32_t tID = startID + nextOffset + j;
                
                fixed64_t w = pool[sID].getWeightTo(connPool, tID);
                fwrite(&w, sizeof(fixed64_t), 1, fp); // 딱 8바이트 가중치 값만 순서대로 저장!
            }
        }
        currentLayerOffset = nextOffset;
    }
    fclose(fp);
    return true;
}

bool BrainNetworkEngine::loadBlockWeights(Cell* pool, CellConn* connPool, uint32_t startID, const uint32_t* layers, int layerCount, const char* filepath) {
    FILE* fp = fopen(filepath, "rb");
    if (!fp) return false;

    uint32_t currentLayerOffset = 0;
    for (int l = 0; l < layerCount - 1; ++l) {
        uint32_t curSize = layers[l];
        uint32_t nextSize = layers[l + 1];
        uint32_t nextOffset = currentLayerOffset + curSize;

        for (uint32_t i = 0; i < curSize; ++i) {
            uint32_t sID = startID + currentLayerOffset + i;
            for (uint32_t j = 0; j < nextSize; ++j) {
                uint32_t tID = startID + nextOffset + j;
                
                fixed64_t w;
                if (fread(&w, sizeof(fixed64_t), 1, fp) != 1) {
                    fclose(fp);
                    return false; 
                }
                
                int slot;
                int32_t chunk = pool[sID].findConnection(connPool, tID, &slot);
                if (chunk != NOCONN) {
                    connPool[chunk].setWeight(slot, w); // 읽어온 가중치를 뇌에 정확히 주입!
                }
            }
        }
        currentLayerOffset = nextOffset;
    }
    fclose(fp);
    return true;
}