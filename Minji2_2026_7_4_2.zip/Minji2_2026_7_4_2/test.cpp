#include "test.hpp"
#include <stdio.h>
#include <string>
#include <filesystem>

// =============================================================================
// 모든 테스트를 일괄 실행하는 래퍼 함수
// =============================================================================
void SystemTester::runAllTests(OfflineMinji& sys) {
    test8BitCascadedAdder(sys);
    testTrendLearning(sys);
    testTokenPerception(sys);
    testDetailedChosungSystem(sys);
    testSemanticAndTrigger(sys);
    test4BitMultiplier(sys);
    testVcpuChaining(sys);
}

// =============================================================================
// 8비트 캐스케이드 전가산기
// =============================================================================
void SystemTester::test8BitCascadedAdder(OfflineMinji& sys) {
    printf("\n==========================================\n");
    printf("[Test] 8비트 전가산기: 전체 조합(0~255) 65536회 전 과정 출력\n");
    printf("==========================================\n");

    auto cellPool = sys.storage.cellArray.getRawPtr();
    size_t cellCount = sys.storage.header->cellCount;
    auto connPool = sys.storage.cellConnArray.getRawPtr();
    size_t connCount = sys.storage.header->cellConnCount;

    if (!cellPool || !connPool) return;

    for (size_t i = 0; i < connCount; i++) {
        connPool[i].reset();
    }

    uint32_t layers[] = {3, 3, 2}; 
    uint32_t baseID = 2000;
    uint32_t cellsPerAdder = 8; 

    for (int i = 0; i < 8; ++i) {
        uint32_t startID = baseID + (i * cellsPerAdder);
        BrainNetworkEngine::buildDenseNetwork(cellPool, cellCount, connPool, connCount, startID, layers, 3, fixed64_t{(int32_t)(200 + i), 0}, false);

        uint32_t id_H1 = startID + 3, id_H2 = startID + 4, id_H3 = startID + 5;
        uint32_t id_Sum = startID + 6, id_Cout = startID + 7;

        cellPool[id_H1].setPThreshold({0, 2147483648}); 
        cellPool[id_H2].setPThreshold({1, 2147483648}); 
        cellPool[id_H3].setPThreshold({2, 2147483648}); 
        cellPool[id_Sum].setPThreshold({0, 2147483648});
        cellPool[id_Cout].setPThreshold({0, 2147483648});

        fixed64_t w_one = {1, 0};
        fixed64_t w_minus_one = {-1, 0};
        fixed64_t w_zero = {0, 0};

        for(int in_idx = 0; in_idx < 3; ++in_idx) {
            for(int h_idx = 0; h_idx < 3; ++h_idx) {
                int slot;
                int32_t chunk = cellPool[startID + in_idx].findConnection(connPool, startID + 3 + h_idx, &slot);
                if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_one);
            }
        }

        int slot; int32_t chunk;
        chunk = cellPool[id_H1].findConnection(connPool, id_Sum, &slot); if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_one);
        chunk = cellPool[id_H2].findConnection(connPool, id_Sum, &slot); if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_minus_one); 
        chunk = cellPool[id_H3].findConnection(connPool, id_Sum, &slot); if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_one);

        chunk = cellPool[id_H1].findConnection(connPool, id_Cout, &slot); if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_zero);
        chunk = cellPool[id_H2].findConnection(connPool, id_Cout, &slot); if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_one);
        chunk = cellPool[id_H3].findConnection(connPool, id_Cout, &slot); if(chunk != NOCONN) connPool[chunk].setWeight(slot, w_zero);
    }

    int successCount = 0;
    fixed64_t e_one = {1, 0};
    fixed64_t e_zero = {0, 0};

    for (uint32_t A = 0; A <= 255; ++A) {
        for (uint32_t B = 0; B <= 255; ++B) {
            uint8_t carry = 0;
            uint32_t sumResult = 0;

            for (int bit = 0; bit < 8; ++bit) {
                uint32_t startID = baseID + (bit * cellsPerAdder);
                uint32_t id_Sum = startID + 6, id_Cout = startID + 7;
                
                for(int c = 0; c < 8; ++c) cellPool[startID + c].setEnergy(e_zero);

                if ((A >> bit) & 1) cellPool[startID + 0].setEnergy(e_one);
                if ((B >> bit) & 1) cellPool[startID + 1].setEnergy(e_one);
                if (carry)          cellPool[startID + 2].setEnergy(e_one);

                for(int in_idx = 0; in_idx < 3; ++in_idx) {
                    if (cellPool[startID + in_idx].getEnergy().i >= 1) { 
                        for(int h_idx = 0; h_idx < 3; ++h_idx) {
                            fixed64_t w = cellPool[startID + in_idx].getWeightTo(connPool, startID + 3 + h_idx);
                            cellPool[startID + 3 + h_idx].addEnergy(w);
                        }
                    }
                }
                
                for(int h_idx = 0; h_idx < 3; ++h_idx) {
                    if (cellPool[startID + 3 + h_idx].isOverPThreshold()) { 
                        for(int out_idx = 0; out_idx < 2; ++out_idx) {
                            fixed64_t w = cellPool[startID + 3 + h_idx].getWeightTo(connPool, startID + 6 + out_idx);
                            cellPool[startID + 6 + out_idx].addEnergy(w);
                        }
                    }
                }

                carry = cellPool[id_Cout].isOverPThreshold() ? 1 : 0;
                if (cellPool[id_Sum].isOverPThreshold()) sumResult |= (1 << bit);
            }
            
            sumResult |= (carry << 8);

            if (A % 100 == 0 && B % 100 == 0) { 
                printf("[Progress] 연산: %u + %u = %u\n", A, B, sumResult);
            }

            if (sumResult == (A + B)) {
                successCount++;
            } else {
                printf("[Error] 연산 오류 발생! A:%u + B:%u = %u (기대값: %u)\n", A, B, sumResult, (A + B));
                return;
            }
        }
    }

    printf("[System] 전체 조합 테스트 대성공! 총 %d / 65536 케이스 통과.\n", successCount);
    printf("==========================================\n\n");
}

// =============================================================================
// 전통적인 방식의 NxNxN 추세 학습 검증
// =============================================================================
void SystemTester::testTrendLearning(OfflineMinji& sys) {
    printf("\n==========================================\n");
    printf("[Test] 전통적 방식의 NxNxN 블록 레이어 추세 학습 (Hebbian Rule)\n");
    printf("==========================================\n");

    auto cellPool = sys.storage.cellArray.getRawPtr();
    size_t cellCount = sys.storage.header->cellCount;
    auto connPool = sys.storage.cellConnArray.getRawPtr();
    size_t connCount = sys.storage.header->cellConnCount;

    if (!cellPool || !connPool) return;

    uint32_t layers[] = {2, 3, 1}; 
    uint32_t baseID = 3000;

    fixed64_t w_init = CellMath::double_to_fixed64(0.1);
    BrainNetworkEngine::buildDenseNetwork(cellPool, cellCount, connPool, connCount, baseID, layers, 3, w_init, true);

    for (int i = 2; i < 5; ++i) cellPool[baseID + i].setPThreshold({0, 2147483648}); 
    cellPool[baseID + 5].setPThreshold({0, 2147483648}); 

    printf("[System] 블록 레이어(2x3x1) 랜덤 가중치 생성 완료.\n");
    printf("[System] 단순 패턴('입력 A' 활성 시 출력 활성) Hebbian 반복 학습 시작...\n");

    fixed64_t eta = CellMath::double_to_fixed64(0.01); 

    for (int epoch = 0; epoch < 50; ++epoch) {
        for (int dataIdx = 0; dataIdx < 2; ++dataIdx) {
            fixed64_t in_A = (dataIdx == 0) ? fixed64_t{1, 0} : fixed64_t{0, 0};
            fixed64_t in_B = (dataIdx == 1) ? fixed64_t{1, 0} : fixed64_t{0, 0};
            fixed64_t target = (dataIdx == 0) ? fixed64_t{1, 0} : fixed64_t{0, 0};

            for (int i = 0; i < 6; ++i) cellPool[baseID + i].setEnergy({0, 0});

            cellPool[baseID + 0].setEnergy(in_A);
            cellPool[baseID + 1].setEnergy(in_B);

            for (int in_idx = 0; in_idx < 2; ++in_idx) {
                if (cellPool[baseID + in_idx].getEnergy().i >= 1 || cellPool[baseID + in_idx].getEnergy().f > 0) {
                    for (int h_idx = 0; h_idx < 3; ++h_idx) {
                        fixed64_t w = cellPool[baseID + in_idx].getWeightTo(connPool, baseID + 2 + h_idx);
                        cellPool[baseID + 2 + h_idx].addEnergy(w);
                    }
                }
            }
            
            for (int h_idx = 0; h_idx < 3; ++h_idx) {
                if (cellPool[baseID + 2 + h_idx].isOverPThreshold()) {
                    fixed64_t h_energy = cellPool[baseID + 2 + h_idx].getEnergy();
                    fixed64_t w = cellPool[baseID + 2 + h_idx].getWeightTo(connPool, baseID + 5);
                    cellPool[baseID + 5].addEnergy(CellMath::fixed64_mul(h_energy, w)); 
                }
            }

            fixed64_t out_val = target;
            if (out_val.i >= 1) {
                for (int in_idx = 0; in_idx < 2; ++in_idx) {
                    if (cellPool[baseID + in_idx].getEnergy().i >= 1) {
                        for (int h_idx = 0; h_idx < 3; ++h_idx) {
                            int slot; int32_t chunk = cellPool[baseID + in_idx].findConnection(connPool, baseID + 2 + h_idx, &slot);
                            if (chunk != NOCONN) {
                                fixed64_t cur_w = connPool[chunk].getWeight(slot);
                                connPool[chunk].setWeight(slot, CellMath::fixed64_hebbian_update(cur_w, cellPool[baseID + in_idx].getEnergy(), out_val, eta));
                            }
                        }
                    }
                }
                for (int h_idx = 0; h_idx < 3; ++h_idx) {
                    if (cellPool[baseID + 2 + h_idx].isOverPThreshold()) {
                        int slot; int32_t chunk = cellPool[baseID + 2 + h_idx].findConnection(connPool, baseID + 5, &slot);
                        if (chunk != NOCONN) {
                            fixed64_t cur_w = connPool[chunk].getWeight(slot);
                            connPool[chunk].setWeight(slot, CellMath::fixed64_hebbian_update(cur_w, cellPool[baseID + 2 + h_idx].getEnergy(), out_val, eta));
                        }
                    }
                }
            }
        }
    }
    
    printf("[System] Hebbian 학습 완료. 결과 테스트 진행:\n");

    for (int dataIdx = 0; dataIdx < 2; ++dataIdx) {
        fixed64_t in_A = (dataIdx == 0) ? fixed64_t{1, 0} : fixed64_t{0, 0};
        fixed64_t in_B = (dataIdx == 1) ? fixed64_t{1, 0} : fixed64_t{0, 0};

        for (int i = 0; i < 6; ++i) cellPool[baseID + i].setEnergy({0, 0});

        cellPool[baseID + 0].setEnergy(in_A);
        cellPool[baseID + 1].setEnergy(in_B);

        for (int in_idx = 0; in_idx < 2; ++in_idx) {
            if (cellPool[baseID + in_idx].getEnergy().i >= 1 || cellPool[baseID + in_idx].getEnergy().f > 0) {
                for (int h_idx = 0; h_idx < 3; ++h_idx) {
                    fixed64_t w = cellPool[baseID + in_idx].getWeightTo(connPool, baseID + 2 + h_idx);
                    cellPool[baseID + 2 + h_idx].addEnergy(w);
                }
            }
        }
        for (int h_idx = 0; h_idx < 3; ++h_idx) {
            if (cellPool[baseID + 2 + h_idx].isOverPThreshold()) {
                fixed64_t h_energy = cellPool[baseID + 2 + h_idx].getEnergy();
                fixed64_t w = cellPool[baseID + 2 + h_idx].getWeightTo(connPool, baseID + 5);
                cellPool[baseID + 5].addEnergy(CellMath::fixed64_mul(h_energy, w)); 
            }
        }

        double e_val = CellMath::fixed64_to_double(cellPool[baseID + 5].getEnergy());
        bool fired = cellPool[baseID + 5].isOverPThreshold();
        printf("  -> 입력 [A:%d, B:%d] | 출력 에너지: %8.4f [%s]\n", 
               (dataIdx == 0 ? 1 : 0), (dataIdx == 1 ? 1 : 0), e_val, 
               fired ? "🔥 발화 (추세 인식)" : "🧊 억제됨");
    }
    
    printf("==========================================\n\n");
}

// =============================================================================
// 초성 링크드 체인 및 임시버퍼 병렬 매칭 테스트부
// =============================================================================
void SystemTester::testTokenPerception(OfflineMinji& sys) {
    printf("\n==========================================\n");
    printf("[Test] 초성 인덱스 테이블 및 링크드 체인 병렬 대입(추론) 연산 검증\n");
    printf("==========================================\n");

    auto tCellPool = sys.storage.tCellArray.getRawPtr();
    auto tConnPool = sys.storage.tCellConnArray.getRawPtr();
    
    if (!tCellPool || !tConnPool) return;

    size_t tConnPoolSize = DEFAULT_TOKEN_CELL_COUNT;
    const char* sampleWords[] = {"철수", "영희", "친구", "사과", "바다"};

    if (sys.storage.getChosungHead(TokenPerceptionEngine::mapEojeolToSlot(sampleWords[0])) == 0xFFFFFFFF) {
        printf("[System] 🌱 초성 지식 기틀이 없습니다. 전체 토큰 가상 메모리를 초기화 및 인덱싱합니다...\n");
        
        for(size_t i = 0; i < DEFAULT_TOKEN_CELL_COUNT; i++) {
            tCellPool[i].initCell(i);
        }
        for(size_t i = 0; i < tConnPoolSize; i++) {
            tConnPool[i].reset();
        }

        for (uint32_t i = 0; i < 5; ++i) {
            tCellPool[i].setAlias(sampleWords[i]);
            tCellPool[i].trainPattern(sampleWords[i], tConnPool, tConnPoolSize, 100);
            tCellPool[i].autoSetThreshold(tConnPool, 0.95);

            bool linked = TokenPerceptionEngine::addTokenToChosungChain(tCellPool, DEFAULT_TOKEN_CELL_COUNT, sys.storage.chosungIndexPtr, i, sampleWords[i]);
            if (linked) {
                printf("  -> [%s] 초성 인덱스 체인 바인딩 성공! (ID: %u, Slot: %u)\n", 
                       sampleWords[i], i, TokenPerceptionEngine::mapEojeolToSlot(sampleWords[i]));
            }
        }
    } else {
        printf("[System] 💾 가상 메모 내에 이미 완벽히 인덱싱된 초성 체인 구조가 발견되어 유지합니다.\n");
    }

    const char* inputSentence = "철수와 영희는 친구다";
    printf("\n[추론 개시] 사용자 입력 문장: \"%s\"\n", inputSentence);

    uint32_t tmpBuffer[16];
    for(int i = 0; i < 16; ++i) tmpBuffer[i] = 0xFFFFFFFF;

    int bufferSize = TokenPerceptionEngine::buildInferenceIndexBuffer(inputSentence, sys.storage.chosungIndexPtr, tmpBuffer, 16);
    printf("[System] 추출된 고유 초성 헤드 개수: %d 개 (임시 버퍼에 내비게이션 오프셋 보관 완료)\n", bufferSize);

    for(size_t i = 0; i < 5; ++i) tCellPool[i].setActive(false);

    TokenPerceptionEngine::scanActiveChosungChains(tCellPool, tConnPool, tmpBuffer, bufferSize, inputSentence);

    printf("\n[System] 체인 스캔 완료! 완벽히 일치하여 활성화(발화)된 토큰셀:\n");
    bool foundActive = false;
    for (size_t i = 0; i < 5; ++i) {
        if (tCellPool[i].isActive()) {
            printf("  -> [🔥 발화!] ID: %u | Alias: '%s' | Threshold: %.4f | Energy: %.4f\n", 
                   tCellPool[i].getID(), tCellPool[i].getAlias(), 
                   CellMath::fixed64_to_double(tCellPool[i].getThreshold()), 
                   CellMath::fixed64_to_double(tCellPool[i].getEnergy()));
            foundActive = true;
        }
    }
    if (!foundActive) {
        printf("  -> (활성화된 토큰이 없습니다.)\n");
    }
    printf("==========================================\n\n");
}

// =============================================================================
// 초성 내비게이션 & 체이닝 아키텍처 정밀 해부 테스트
// =============================================================================
void SystemTester::testDetailedChosungSystem(OfflineMinji& sys) {
    printf("\n==========================================\n");
    printf("[Test] 초성 내비게이션 & 꼬리 물기 체인 정밀 검증 (Detailed)\n");
    printf("==========================================\n");

    auto tCellPool = sys.storage.tCellArray.getRawPtr();
    auto tConnPool = sys.storage.tCellConnArray.getRawPtr();
    uint32_t* chosungPtr = sys.storage.chosungIndexPtr;

    if (!tCellPool || !tConnPool || !chosungPtr) return;

    printf("\n[1단계] 어절 초성 슬롯 매핑 정밀 테스트\n");
    const char* words[] = {"Apple", "123", "사과", "학교", "!@#"};
    for(int i = 0; i < 5; i++) {
        uint16_t slot = TokenPerceptionEngine::mapEojeolToSlot(words[i]);
        printf("  -> 단어 '%s' 매핑 슬롯 번호: %u\n", words[i], slot);
    }

    printf("\n[2단계] 토큰 등록, 중복 방어 및 꼬리물기(체이닝) 검증\n");
    uint32_t baseID = 9000;
    const char* chainWords[] = {"사탕", "사탕", "사자", "사다리"}; 
    
    for(int i = 0; i < 4; i++) tCellPool[baseID + i].initCell(baseID + i);
    uint16_t slot_S = TokenPerceptionEngine::mapEojeolToSlot("사탕");
    uint32_t backupHead = chosungPtr[slot_S];
    chosungPtr[slot_S] = 0xFFFFFFFF; 

    for(int i = 0; i < 4; i++) {
        tCellPool[baseID + i].setAlias(chainWords[i]);
        tCellPool[baseID + i].trainPattern(chainWords[i], tConnPool, DEFAULT_TOKEN_CELL_COUNT, 10);
        tCellPool[baseID + i].autoSetThreshold(tConnPool, 0.95);

        bool linked = TokenPerceptionEngine::addTokenToChosungChain(tCellPool, DEFAULT_TOKEN_CELL_COUNT, chosungPtr, baseID + i, chainWords[i]);
        if (linked) {
            printf("  -> ✅ [%s] (ID: %u) 등록 및 체인 바인딩 성공!\n", chainWords[i], baseID + i);
        } else {
            printf("  -> ❌ [%s] (ID: %u) 등록 실패! (Alias 중복 방어망 완벽 작동)\n", chainWords[i], baseID + i);
        }
    }

    printf("\n[3단계] 링크드 리스트 앞뒤 연결 무결성 확인 (포인터 순회)\n");
    uint32_t curr = chosungPtr[slot_S];
    int step = 0;
    while(curr != 0xFFFFFFFF) {
        int32_t prev = tCellPool[curr].getPrev();
        int32_t next = tCellPool[curr].getNext();
        printf("  -> 체인 뎁스 [%d] ID: %u ('%s') | 이전(Prev) 오프셋: %d | 다음(Next) 오프셋: %d\n", 
               step++, curr, tCellPool[curr].getAlias(), prev, next);
        if (next == 0) break; 
        curr = (uint32_t)((int32_t)curr + next);
    }

    printf("\n[4단계] 임시 버퍼 기반 초성 고속 병렬 스캔 검증\n");
    const char* testSentence = "동물원에 있는 사자 그리고 달콤한 사탕";
    printf("  -> 입력 문장: \"%s\"\n", testSentence);
    
    uint32_t tmpBuffer[16];
    int bufferCount = TokenPerceptionEngine::buildInferenceIndexBuffer(testSentence, chosungPtr, tmpBuffer, 16);
    printf("  -> 추출된 고유 초성 헤드 개수: %d 개 (임시 버퍼 장전)\n", bufferCount);

    for(int i = 0; i < 4; i++) tCellPool[baseID + i].setActive(false);

    TokenPerceptionEngine::scanActiveChosungChains(tCellPool, tConnPool, tmpBuffer, bufferCount, testSentence);

    printf("\n  [최종 발화(Hit)된 토큰 목록]\n");
    bool hit = false;
    for(int i = 0; i < 4; i++) {
        if (tCellPool[baseID + i].isActive()) {
            printf("  -> 🔥 정확히 일치하여 활성화됨: ID %u ('%s')\n", baseID + i, tCellPool[baseID + i].getAlias());
            hit = true;
        }
    }
    if(!hit) printf("  -> (활성화된 토큰 없음)\n");

    chosungPtr[slot_S] = backupHead;
    
    printf("==========================================\n\n");
}

// =============================================================================
// SemanticEngine & VirtualExecutionEngine 통합 검증
// =============================================================================
void SystemTester::testSemanticAndTrigger(OfflineMinji& sys) {
    printf("\n==========================================\n");
    printf("[Test] SemanticEngine & VirtualExecutionEngine 통합 테스트\n");
    printf("==========================================\n");

    auto cellPool = sys.storage.cellArray.getRawPtr();
    size_t cellCount = sys.storage.header->cellCount;
    auto connPool = sys.storage.cellConnArray.getRawPtr();
    size_t connCount = sys.storage.header->cellConnCount;

    if (!cellPool || !connPool) return;

    fixed64_t w_one = {1, 0};
    bool linked = SemanticEngine::linkFactRelation(cellPool, cellCount, connPool, connCount, "사과", "빨간색", w_one);
    
    if (linked) {
        printf("[System] 팩트 링커 성공: '사과'는 '빨간색'이다. (가중치 1.0)\n");
    } else {
        printf("[Error] 팩트 링커 실패.\n");
        return;
    }

    uint32_t redID = SemanticEngine::getOrCreateNode(cellPool, cellCount, "빨간색");
    sys.execEngine.bindScriptToCell(redID, "print_red_info.vsh");
    
    cellPool[redID].setExecFlag(true); 
    printf("[System] '빨간색' 셀(ID: %u)에 스크립트(print_red_info.vsh) 바인딩 및 execFlag ON 완료.\n", redID);

    SemanticEngine::resetNetworkEnergy(cellPool, cellCount);
    
    uint32_t appleID = SemanticEngine::getOrCreateNode(cellPool, cellCount, "사과");
    printf("\n[System] '사과' 셀(ID: %u)에 강한 자극(에너지 1.0) 주입!\n", appleID);
    
    cellPool[appleID].setEnergy(w_one);

    printf("[System] 에너지 전파 (Forward Pass) 1단계 진행...\n");
    
    int32_t currentChunk = (cellPool[appleID].getConnOffset() == 0xFFFFFFFF) ? NOCONN : (int32_t)cellPool[appleID].getConnOffset();
    
    while (currentChunk != NOCONN) {
        for (int i = 0; i < MAX_CONN_A_UNIT; ++i) {
            uint32_t tID = connPool[currentChunk].getTargetID(i);
            if (tID != 0xFFFFFFFF) {
                fixed64_t w = connPool[currentChunk].getWeight(i);
                
                fixed64_t srcEnergy = cellPool[appleID].getEnergy();
                fixed64_t propagated = CellMath::fixed64_mul(srcEnergy, w);
                
                cellPool[tID].addEnergy(propagated);
            }
        }
        currentChunk = connPool[currentChunk].getNextChunk();
    }

    SemanticEngine::printFiredNodes(cellPool, cellCount);
    auto blockPool = sys.storage.execBlockArray.getRawPtr();
    uint32_t blockPoolSize = sys.storage.header->execBlockCount;
    sys.execEngine.scanAndTriggerScripts(cellPool, cellCount, blockPool, blockPoolSize);
    
    printf("==========================================\n\n");
}

// =============================================================================
// 4비트 승산기 자동 학습
// =============================================================================
void SystemTester::test4BitMultiplier(OfflineMinji& sys) {
    auto cellPool = sys.storage.cellArray.getRawPtr();
    size_t cellCount = sys.storage.header->cellCount;
    auto connPool = sys.storage.cellConnArray.getRawPtr();
    size_t connCount = sys.storage.header->cellConnCount;

    if (!cellPool || !connPool) return;

    uint32_t layers[] = {8, 64, 64, 8}; 
    uint32_t baseID = 4000;
    bool success = false;
    
    std::string savePath = ".system/autoLearn/mul4x4.learn";

    if (std::filesystem::exists(savePath)) {
        printf("[System] 💾 모듈식 학습 파일 발견! 4비트 곱셈기 지식을 로드합니다: %s\n", savePath.c_str());
        BrainNetworkEngine::buildDenseNetwork(cellPool, cellCount, connPool, connCount, baseID, layers, 4, CellMath::double_to_fixed64(0.0), false);
        success = BrainNetworkEngine::loadBlockWeights(cellPool, connPool, baseID, layers, 4, savePath.c_str());
    } else {
        printf("[System] 🌱 저장된 모듈이 없습니다. 4비트 곱셈기 훈련을 새롭게 시작합니다...\n");
        BrainNetworkEngine::buildDenseNetwork(cellPool, cellCount, connPool, connCount, baseID, layers, 4, CellMath::double_to_fixed64(0.1), true);
        printf("[System] 🕸️ 8x64x64x8 곱셈기 밀집망 시냅스 생성 완료!\n");
        
        size_t dataCount = 256; 
        fixed64_t* trainData = new fixed64_t[dataCount * 8];
        fixed64_t* targetData = new fixed64_t[dataCount * 8];

        for (int a = 0; a < 16; ++a) {
            for (int b = 0; b < 16; ++b) {
                int idx = a * 16 + b;
                for(int i = 0; i < 8; ++i) {
                    trainData[idx * 8 + i] = {0, 0};
                    targetData[idx * 8 + i] = {0, 0};
                }
                if(a & 1) trainData[idx * 8 + 0] = {1, 0};
                if(a & 2) trainData[idx * 8 + 1] = {1, 0};
                if(a & 4) trainData[idx * 8 + 2] = {1, 0};
                if(a & 8) trainData[idx * 8 + 3] = {1, 0};
                
                if(b & 1) trainData[idx * 8 + 4] = {1, 0};
                if(b & 2) trainData[idx * 8 + 5] = {1, 0};
                if(b & 4) trainData[idx * 8 + 6] = {1, 0};
                if(b & 8) trainData[idx * 8 + 7] = {1, 0};

                int res = a * b;
                for(int i = 0; i < 8; ++i) {
                    targetData[idx * 8 + i] = ((res >> i) & 1) ? fixed64_t{1, 0} : fixed64_t{0, 0};
                }
            }
        }

        success = BrainNetworkEngine::autoTrainBlockLayer(
            cellPool, cellCount, connPool, connCount,
            baseID, layers, 4,
            trainData, targetData, dataCount,
            CellMath::double_to_fixed64(0.001), 
            50000,                              
            CellMath::double_to_fixed64(0.05),  
            "mul4x4.learn"   
        );
        
        delete[] trainData;
        delete[] targetData;
    }

    if (success) {
        printf("[System] 4비트 곱셈기 준비 완료!\n");
        printf("\n==========================================\n");
        printf("[System] 🧠 학습된 뇌세포를 이용한 추론(연산) 테스트 시작!\n");
        printf("==========================================\n");

        int successCount = 0;
        uint32_t totalCells = 8 + 64 + 64 + 8; 
        uint32_t outOffset = totalCells - 8;   
        
        for (int a = 0; a < 16; ++a) {
            for (int b = 0; b < 16; ++b) {
                for (uint32_t i = 0; i < totalCells; ++i) {
                    cellPool[baseID + i].setEnergy({0, 0});
                }

                if(a & 1) cellPool[baseID + 0].setEnergy({1, 0});
                if(a & 2) cellPool[baseID + 1].setEnergy({1, 0});
                if(a & 4) cellPool[baseID + 2].setEnergy({1, 0});
                if(a & 8) cellPool[baseID + 3].setEnergy({1, 0});
                
                if(b & 1) cellPool[baseID + 4].setEnergy({1, 0});
                if(b & 2) cellPool[baseID + 5].setEnergy({1, 0});
                if(b & 4) cellPool[baseID + 6].setEnergy({1, 0});
                if(b & 8) cellPool[baseID + 7].setEnergy({1, 0});

                uint32_t currentLayerOffset = 0;
                for (size_t l = 0; l < 3; ++l) { 
                    uint32_t curLayerSize = layers[l];
                    uint32_t nextLayerSize = layers[l + 1];
                    uint32_t nextLayerOffset = currentLayerOffset + curLayerSize;

                    for (uint32_t i = 0; i < curLayerSize; ++i) {
                        uint32_t sourceID = baseID + currentLayerOffset + i;
                        double f_sEnergy = CellMath::fixed64_to_double(cellPool[sourceID].getEnergy());
                        
                        if (f_sEnergy > 1.0) f_sEnergy = 1.0;
                        if (f_sEnergy < 0.0) f_sEnergy = 0.0;
                        cellPool[sourceID].setEnergy(CellMath::double_to_fixed64(f_sEnergy));

                        if (f_sEnergy > 0.0) {
                            for (uint32_t j = 0; j < nextLayerSize; ++j) {
                                uint32_t targetID = baseID + nextLayerOffset + j;
                                fixed64_t w = cellPool[sourceID].getWeightTo(connPool, targetID);
                                double f_w = CellMath::fixed64_to_double(w);
                                
                                double propagated = f_sEnergy * f_w;
                                cellPool[targetID].addEnergy(CellMath::double_to_fixed64(propagated));
                            }
                        }
                    }
                    currentLayerOffset = nextLayerOffset;
                }
                
                for (uint32_t o = 0; o < 8; ++o) {
                    uint32_t outID = baseID + outOffset + o;
                    double f_out = CellMath::fixed64_to_double(cellPool[outID].getEnergy());
                    if (f_out > 1.0) f_out = 1.0;
                    if (f_out < 0.0) f_out = 0.0;
                    cellPool[outID].setEnergy(CellMath::double_to_fixed64(f_out));
                }

                int expected = a * b;
                int predicted = 0;
                for (int i = 0; i < 8; ++i) {
                    double f_out = CellMath::fixed64_to_double(cellPool[baseID + outOffset + i].getEnergy());
                    if (f_out >= 0.5) { 
                        predicted |= (1 << i);
                    }
                }

                bool isCorrect = (expected == predicted);
                if (isCorrect) successCount++;
                
                // 불필요한 프린트 너무 길면 꺼둘 수 있게 주석 처리 가능
                printf("  -> 연산: %2d x %2d = 예측값 %3d | 정답 %3d [%s]\n", a, b, predicted, expected, isCorrect ? "✅ 정답" : "❌ 오답");
            }
        }
        printf("\n[System] 테스트 완료! 총 256개 케이스 중 %d개 적중!\n", successCount);
    }
}

// =============================================================================
// vCPU 확장 블록 메모리 마구잡이 점프 체이닝 테스트
// =============================================================================
void SystemTester::testVcpuChaining(OfflineMinji& sys) {
    printf("\n==========================================\n");
    printf("[Test] vCPU 확장 블록 메모리 체이닝 (마구잡이 번지 점프) 테스트\n");
    printf("==========================================\n");

    auto cellPool = sys.storage.cellArray.getRawPtr();
    size_t cellCount = sys.storage.header->cellCount;
    auto blockPool = sys.storage.execBlockArray.getRawPtr();
    size_t blockPoolSize = sys.storage.header->execBlockCount;

    // 1. 임의의 셀(ID: 99) 생성 및 실행 허가 설정
    uint32_t targetID = 99;
    cellPool[targetID].initCell(targetID);
    cellPool[targetID].setAlias("체인마스터");
    cellPool[targetID].setPThreshold(CellMath::double_to_fixed64(0.5));
    cellPool[targetID].setExecFlag(true);

    // 2. 스크립트 바인딩 (이때 내장 기본 명령 0xAAAA0001이 세팅됨)
    sys.execEngine.bindScriptToCell(targetID, "chain_macro.vsh");

    // 3. 확장 블록 메모리를 마구 헤집으면서 꼬리물기 체인 엮기!
    // 10번 번지 -> 404번 번지 -> 77번 번지 -> 끝 (마구잡이 점프)
    uint32_t jump1 = 10;
    uint32_t jump2 = 404;
    uint32_t jump3 = 77;

    blockPool[jump1].reset();
    blockPool[jump1].setCmd(0, 0xBBBB0001); // 두 번째 블록 시작
    blockPool[jump1].setCmd(1, 0xBBBB0002);
    blockPool[jump1].setToNext(jump2); // 404번으로 점프 지시!

    blockPool[jump2].reset();
    blockPool[jump2].setCmd(0, 0xCCCC0001); // 세 번째 블록 시작
    blockPool[jump2].setToNext(jump3); // 77번으로 점프 지시!

    blockPool[jump3].reset();
    blockPool[jump3].setCmd(0, 0xDDDD0001); // 네 번째 블록 시작
    blockPool[jump3].setCmd(3, 0xDDDD0004);
    blockPool[jump3].setToNext(0xFFFFFFFF); // 체인 종료(NOCONN)

    // 4. vCPU 레지스트리에 첫 번째 점프 위치(10번 번지) 알려주기
    sys.execEngine.setExtBlockHeadForCell(targetID, jump1);

    // 5. 셀 발화! (에너지 1.0 주입)
    printf("[System] '체인마스터' 셀에 강제 발화 에너지 주입!\n");
    cellPool[targetID].setEnergy(CellMath::double_to_fixed64(1.0));

    // 6. 엔진 인터럽트 스캔 및 연속 트리거!
    sys.execEngine.scanAndTriggerScripts(cellPool, cellCount, blockPool, blockPoolSize);
    printf("==========================================\n");
}