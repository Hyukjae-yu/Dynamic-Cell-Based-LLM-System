#ifndef __CELL_TYPES_H__
#define __CELL_TYPES_H__

#include <stdio.h>
#include <stdint.h>
#include <filesystem>

// 🔥 오빠가 짠 고정소수점 연산 라이브러리 전역 연동!
#include "cellMath.hpp"

// 매크로 정의
#define MOVE_CURSOR(row, col)   printf("\033[%d;%dH", (row), (col))
#define RESET_COLOR             printf("\033[0m")
#define CLEAR_SCREEN            printf("\033[2J")
// 표준 색상
#define SET_BLACK               printf("\033[30m")
#define SET_RED                 printf("\033[31m")
#define SET_GREEN               printf("\033[32m")
#define SET_YELLOW              printf("\033[33m")
#define SET_BLUE                printf("\033[34m")
#define SET_MAGENTA             printf("\033[35m")
#define SET_CYAN                printf("\033[36m")
#define SET_WHITE               printf("\033[37m")
#define SET_GRAY                printf("\033[90m")
// 밝은 색상
#define SET_LIGHT_RED           printf("\033[91m")
#define SET_LIGHT_GREEN         printf("\033[92m")
#define SET_LIGHT_YELLOW        printf("\033[93m")
#define SET_LIGHT_BLUE          printf("\033[94m")
#define SET_LIGHT_MAGENTA       printf("\033[95m")
#define SET_LIGHT_CYAN          printf("\033[96m")
#define SET_LIGHT_WHITE         printf("\033[97m")

#define SYSTEM_DIR_PATH  "./.system"
#define MASTER_FILE_PATH "./.system/system.bin"
#define AUTO_LEARN_PATH  ".system/autoLearn/"

// 시스템 부팅 및 가상 메모리 초기 생성용 디폴트 규격
#define DEFAULT_EXECUTION_CONTEXT_COUNT     100
#define DEFAULT_TOKEN_CELL_COUNT            10000
#define MAX_TOKEN_INPUTS                    16
#define MAX_TOKEN_CONNECTIONS               16      //  토큰셀 한개가 동시에 연결될수 있는 의미셀 수.
#define DEFAULT_MEANING_CELL_COUNT          50000
#define DEFAULT_CONN_COUNT                  200000

#define DEFAULT_EXEC_BLOCK_COUNT            5000     // 신설할 확장 코드 블록 풀의 개수
#define vCPU_BASIC_CMD_SIZE                 4        // 32비트 명령어 4개 (기본 단위)
#define EXEC_BLOCK_NO_LINK                  ((uint32_t)0xFFFFFFFF)


//  각종 변수와 어레이 설정 관랸.
#define NICKNAME_LENGTHc                    64      //  의미셀의 별명 텍스트 길이.
#define NICKNAME_LENGTHt                    64      //  토큰셀의 별명 텍스트 길이.


//  셀 연결 클래스 관련 디폴트 파라미터.
#define MAX_CONN_A_UNIT                     64
#define NOCONN                              ((int32_t)0x80000000)

// 🔥 새로 추가된 기능 타입 상수 (A는 B다 사실 관계 링크용)
#define FUNC_FACT_RELATION                  10

#endif