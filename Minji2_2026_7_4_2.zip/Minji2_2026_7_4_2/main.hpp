#ifndef __MAIN_HPP__
#define __MAIN_HPP__

// 1. 기초 규격 및 수학 코어
#include "cellTypes.hpp"

// 2. 스토리지 및 네트워크 엔진
#include "MmapStorageManager.hpp"
#include "BrainNetworkEngine.hpp"
#include "TokenPerceptionEngine.hpp"

// 3. 고위 논리 및 실행 엔진
#include "SemanticEngine.hpp"
#include "VirtualExecutionEngine.hpp"

// 4. 시스템 관리 유틸
#include "SystemManager.hpp"

class OfflineMinji {
public: // 🔥 테스터(외부 모듈)가 C스타일로 직접 제어할 수 있도록 public 전면 개방!
    MmapStorageManager storage;
    TokenPerceptionEngine tokenEngine;
    BrainNetworkEngine brainEngine;
    VirtualExecutionEngine execEngine;
    SystemManager sysManager;

    bool bootUpSystem();
    void shutDownSystem();
};

#endif
