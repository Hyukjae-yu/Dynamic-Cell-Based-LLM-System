#ifndef __SEMANTICENGINE__
#define __SEMANTICENGINE__

#include "BrainNetworkEngine.hpp"
#include "cellTypes.hpp"
#include "cellMath.hpp"

class SemanticEngine {
public:
    // 1. 단어(Alias)로 셀을 찾고, 없으면 빈 셀을 찾아 동적 할당
    static uint32_t getOrCreateNode(BrainNetworkEngine::Cell* pool, size_t poolSize, const char* alias);
    
    // 2. 'A는 B다' 관계 자동 링커 (FUNC_FACT_RELATION 적용)
    static bool linkFactRelation(BrainNetworkEngine::Cell* pool, size_t poolSize, 
                                 BrainNetworkEngine::CellConn* connPool, size_t connPoolSize,
                                 const char* subject, const char* object, fixed64_t weight);
    
    // 3. 다음 추론을 위한 전체 네트워크 에너지 초기화
    static void resetNetworkEnergy(BrainNetworkEngine::Cell* pool, size_t poolSize);
    
    // 4. 발화된 셀(Threshold 초과) 스냅샷 출력
    static void printFiredNodes(BrainNetworkEngine::Cell* pool, size_t poolSize);
};

#endif