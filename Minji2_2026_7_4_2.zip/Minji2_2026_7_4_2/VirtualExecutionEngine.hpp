#ifndef __VIRTUALEXECUTIONENGINE__
#define __VIRTUALEXECUTIONENGINE__

#include "BrainNetworkEngine.hpp"
#include <stdint.h>
#include <string.h>

#define MAX_SCRIPT_TRIGGERS 1024

class VirtualExecutionEngine {
public:
    // 1. 신설된 가변 확장 코드 블록 구조체 (32bit*4 명령어 + 꼬리물기 포인터)
    class ExecBlock {
    private:
        uint32_t cmdBuffer[vCPU_BASIC_CMD_SIZE]; // 32bit x 4 기본 명령 공간 (16바이트)
        uint32_t toNext;                         // 다음 블록 인덱스 (4바이트)
        uint32_t reserved;                       // 64비트 정렬용 패딩 (4바이트) -> 총 24바이트

    public:
        void reset() {
            memset(cmdBuffer, 0, sizeof(cmdBuffer));
            toNext = 0xFFFFFFFF;
            reserved = 0;
        }
        uint32_t getCmd(int idx) const { return (idx >= 0 && idx < 4) ? cmdBuffer[idx] : 0; }
        void setCmd(int idx, uint32_t val) { if (idx >= 0 && idx < 4) cmdBuffer[idx] = val; }
        uint32_t getToNext() const { return toNext; }
        void setToNext(uint32_t nextIdx) { toNext = nextIdx; }
    };

    // 2. 기존 ExecutionContext 구조 업그레이드
    class ExecutionContext {
    private:
        uint32_t cellID;
        uint32_t basicCmds[vCPU_BASIC_CMD_SIZE]; // 오빠가 말한 기본 32bit*4 내장 vCPU 버퍼
        uint32_t extBlockHead;                   // [신설] 부족할 때 점프할 뒷쪽 확장 메모리 오프셋 ID
        bool isRegistered;
        uint8_t reserved[3];

    public:
        void reset() {
            cellID = 0xFFFFFFFF;
            memset(basicCmds, 0, sizeof(basicCmds));
            extBlockHead = 0xFFFFFFFF; // 연결 없음 상태로 초기화
            isRegistered = false;
            memset(reserved, 0, sizeof(reserved));
        }

        uint32_t getCellID() const { return cellID; }
        void setCellID(uint32_t id) { cellID = id; }
        bool getIsRegistered() const { return isRegistered; }
        void setIsRegistered(bool flag) { isRegistered = flag; }
        
        uint32_t getBasicCmd(int idx) const { return basicCmds[idx]; }
        void setBasicCmd(int idx, uint32_t val) { if(idx >= 0 && idx < 4) basicCmds[idx] = val; }
        
        uint32_t getExtBlockHead() const { return extBlockHead; }
        void setExtBlockHead(uint32_t headIdx) { extBlockHead = headIdx; }
    };

private:
    ExecutionContext registry[MAX_SCRIPT_TRIGGERS];

public:
    VirtualExecutionEngine();
    ~VirtualExecutionEngine();

    bool bindScriptToCell(uint32_t cellID, const char* dummyPath); 
    bool unbindScriptFromCell(uint32_t cellID);

    // 오빠가 구상한 vCPU 2단계 연속 실행 매커니즘의 시뮬레이터 코어!
    void executeVcpuChain(const ExecutionContext& context, ExecBlock* blockPool, uint32_t blockPoolSize);
    void scanAndTriggerScripts(BrainNetworkEngine::Cell* cellPool, size_t poolSize, ExecBlock* blockPool, uint32_t blockPoolSize);
    bool setExtBlockHeadForCell(uint32_t cellID, uint32_t headIdx);
};

#endif