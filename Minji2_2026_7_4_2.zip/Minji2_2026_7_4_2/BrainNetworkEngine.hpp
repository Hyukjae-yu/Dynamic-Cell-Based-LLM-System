#ifndef __BRAINNETWORKENGINE__
#define __BRAINNETWORKENGINE__

#include "cellTypes.hpp"

class BrainNetworkEngine {
public:
    class CellConn;

    // -------------------------------------------------------------------------
    // 🧠 1. 단일 의미 세포 (Node)
    // -------------------------------------------------------------------------
    class Cell {
    private:
        uint32_t id;
        char alias[NICKNAME_LENGTHc];         
        fixed64_t pThreshold;   
        fixed64_t nThreshold;   
        fixed64_t energy;
        uint64_t connOffset;    
        
        bool activeFlag;        
        bool execFlag;          
        uint8_t reserved[6];    

    public:
        void initCell(uint32_t newID);
        void setID(uint32_t newID);
        uint32_t getID() const;
        uint64_t getConnOffset() const; 
        void setConnOffset(uint64_t offset);
        
        void setAlias(const char* name);
        const char* getAlias() const;
        
        void setActive(bool flag);
        bool isActive() const;
        void toggleActive();

        void setExecFlag(bool flag);
        bool isExec() const;

        void setEnergy(fixed64_t e);
        fixed64_t getEnergy() const;    
        void addEnergy(fixed64_t e);
        void subEnergy(fixed64_t e);
        
        void setPThreshold(fixed64_t p);
        fixed64_t getPThreshold() const;
        void setNThreshold(fixed64_t n);
        fixed64_t getNThreshold() const;
        
        bool isOverPThreshold() const; 
        bool isUnderNThreshold() const;

        int32_t findConnection(CellConn* connPool, uint32_t targetID, int* outSlot) const;
        bool addConnection(CellConn* connPool, size_t connPoolSize, uint32_t sID, uint32_t tID, fixed64_t w, uint8_t assoc);
        bool removeConnection(CellConn* connPool, uint32_t targetID);
        fixed64_t getWeightTo(CellConn* connPool, uint32_t targetID) const;

        bool addConnectionByAlias(Cell* cellPool, size_t cellPoolSize, CellConn* connPool, size_t connPoolSize, uint32_t sID, const char* targetAlias, fixed64_t w, uint8_t assoc);
        bool isConnectedToAlias(Cell* cellPool, size_t cellPoolSize, CellConn* connPool, const char* targetAlias) const;
    };

    // -------------------------------------------------------------------------
    // 🕸️ 2. 세포 간 연결 청크 (Edge)
    // -------------------------------------------------------------------------
    class CellConn {
    private:
        fixed64_t weight[MAX_CONN_A_UNIT];      
        uint32_t  sourceID[MAX_CONN_A_UNIT];    
        uint32_t  targetID[MAX_CONN_A_UNIT];    
        uint8_t   association[MAX_CONN_A_UNIT]; 

        int32_t   toPrevious;                   
        int32_t   toNext;                       
        bool      tokenFlag;                    
        uint8_t   reserved[7];                  

    public:
        void reset();
        bool isFull() const;
        bool isEmpty() const;
        int getUsedCount() const;

        int findEmptySlot() const;
        int findTarget(uint32_t tID) const;
        
        bool connect(int slot, uint32_t sID, uint32_t tID, fixed64_t w, uint8_t assoc);
        void disconnect(int slot);
        
        uint32_t getSourceID(int slot) const;
        uint32_t getTargetID(int slot) const;
        uint8_t getAssociation(int slot) const;
        void setAssociation(int slot, uint8_t assoc);

        fixed64_t getWeight(int slot) const;
        void setWeight(int slot, fixed64_t w);
        void addWeight(int slot, fixed64_t w);
        void subWeight(int slot, fixed64_t w);
        void applyDecay(fixed64_t decayRate); 

        void setNextChunk(int32_t relativePos);
        int32_t getNextChunk() const;
        void setPrevChunk(int32_t relativePos);
        int32_t getPrevChunk() const;
        bool hasNext() const;   
        bool hasPrev() const;   
    };

    // -------------------------------------------------------------------------
    // 🚀 3. 글로벌 스캔 / 유틸리티 / 다층 신경망 빌더
    // -------------------------------------------------------------------------
    static uint32_t findIDByAlias(Cell* pool, size_t poolSize, const char* name);
    static bool fireCellByAlias(Cell* pool, size_t poolSize, const char* name);
    static bool toggleCellByAlias(Cell* pool, size_t poolSize, const char* name);
    static void clearAllActiveFlags(Cell* pool, size_t poolSize);
    static int32_t findFreeConnChunk(CellConn* connPool, size_t connPoolSize);

    static bool buildDenseNetwork(Cell* cellPool, size_t cellPoolSize, CellConn* connPool, size_t connPoolSize, 
                                  uint32_t startID, const uint32_t* layerSizes, int layerCount, fixed64_t w_init, bool initRandom = true);

    static bool autoTrainBlockLayer(
        Cell* pool, size_t poolSize,
        CellConn* connPool, size_t connPoolSize,
        uint32_t startID,               
        const uint32_t* layers,               
        size_t layerCount,              
        fixed64_t* trainingData,        
        fixed64_t* targetData,          
        size_t dataCount,               
        fixed64_t learningRate,         
        int maxEpochs,                  
        fixed64_t targetErrorLimit,
        const char* saveFileName      
    );

    // 🔥 글로벌 파일 저장/로드 유틸리티 (올바른 위치 안착!)
    static bool saveBlockWeights(Cell* pool, CellConn* connPool, uint32_t startID, const uint32_t* layers, int layerCount, const char* filepath);
    static bool loadBlockWeights(Cell* pool, CellConn* connPool, uint32_t startID, const uint32_t* layers, int layerCount, const char* filepath);

    BrainNetworkEngine();
    ~BrainNetworkEngine();
};

#endif