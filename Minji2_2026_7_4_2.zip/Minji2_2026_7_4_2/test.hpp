#ifndef __TEST_HPP__
#define __TEST_HPP__

#include "main.hpp" // OfflineMinji 규격만 참조하므로 순환 참조 발생 안 함!

class SystemTester {
public:
    // 테스트 기능들을 static으로 빼서 언제든 편하게 호출하도록 구성했어
    static void test8BitCascadedAdder(OfflineMinji& sys);
    static void testTrendLearning(OfflineMinji& sys);
    static void testTokenPerception(OfflineMinji& sys);
    static void testDetailedChosungSystem(OfflineMinji& sys);
    static void testSemanticAndTrigger(OfflineMinji& sys);
    static void test4BitMultiplier(OfflineMinji& sys);
    static void testVcpuChaining(OfflineMinji& sys);
    // 이 함수 하나로 메인에서 모든 테스트를 한 방에 돌릴 수 있어!
    static void runAllTests(OfflineMinji& sys);
};

#endif