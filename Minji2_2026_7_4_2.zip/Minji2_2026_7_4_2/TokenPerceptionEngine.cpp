#include "TokenPerceptionEngine.hpp"
#include <string.h>
#include <stdio.h>
#include <math.h>

// =============================================================================
// [TokenPerceptionEngine::tCell] 멤버 함수 구현부
// =============================================================================
void TokenPerceptionEngine::tCell::initCell(uint32_t newID) {
    this->id = newID;
    memset(this->alias, 0, sizeof(this->alias));
    
    this->energy = {0, 0};
    this->threshold = {0, 0}; 
    
    this->toPrevious = 0; // 초기 상태 상대링크 거리는 0으로 정렬 대기
    this->toNext = 0;
    
    for (int i = 0; i < MAX_TOKEN_CONNECTIONS; ++i) {
        this->targetID[i] = 0xFFFFFFFF;
    }
    
    this->tConnectionOffset = 0xFFFFFFFF; 
    this->activeFlag = false;  
    this->learnable = true;
    this->execFlag = false;
}

void TokenPerceptionEngine::tCell::setID(uint32_t newID) { this->id = newID; }
uint32_t TokenPerceptionEngine::tCell::getID() const { return this->id; }

void TokenPerceptionEngine::tCell::setAlias(const char* name) {
    if (!name) return;
    strncpy(this->alias, name, NICKNAME_LENGTHt - 1);
    this->alias[NICKNAME_LENGTHt - 1] = '\0';
}
const char* TokenPerceptionEngine::tCell::getAlias() const { return this->alias; }

void TokenPerceptionEngine::tCell::setEnergy(fixed64_t e) { this->energy = e; }
fixed64_t TokenPerceptionEngine::tCell::getEnergy() const { return this->energy; }
void TokenPerceptionEngine::tCell::addEnergy(fixed64_t e) { this->energy = CellMath::fixed64_add(this->energy, e); }
void TokenPerceptionEngine::tCell::subEnergy(fixed64_t e) { this->energy = CellMath::fixed64_sub(this->energy, e); }
void TokenPerceptionEngine::tCell::clearEnergy() { this->energy = {0, 0}; } 

void TokenPerceptionEngine::tCell::setThreshold(fixed64_t t) { this->threshold = t; }
fixed64_t TokenPerceptionEngine::tCell::getThreshold() const { return this->threshold; }

bool TokenPerceptionEngine::tCell::isOverThreshold() const {
    return (this->energy.i > this->threshold.i) || 
           (this->energy.i == this->threshold.i && this->energy.f >= this->threshold.f);
}

void TokenPerceptionEngine::tCell::setNext(int32_t relativePos) { this->toNext = relativePos; }
int32_t TokenPerceptionEngine::tCell::getNext() const { return this->toNext; }
void TokenPerceptionEngine::tCell::setPrev(int32_t relativePos) { this->toPrevious = relativePos; }
int32_t TokenPerceptionEngine::tCell::getPrev() const { return this->toPrevious; }

bool TokenPerceptionEngine::tCell::addTarget(uint32_t mCellID) {
    for (int i = 0; i < MAX_TOKEN_CONNECTIONS; ++i) {
        if (this->targetID[i] == mCellID) return true;
        if (this->targetID[i] == 0xFFFFFFFF) {
            this->targetID[i] = mCellID;
            return true;
        }
    }
    return false;
}

void TokenPerceptionEngine::tCell::removeTarget(uint32_t mCellID) {
    for (int i = 0; i < MAX_TOKEN_CONNECTIONS; ++i) {
        if (this->targetID[i] == mCellID) {
            this->targetID[i] = 0xFFFFFFFF;
            return;
        }
    }
}

int TokenPerceptionEngine::tCell::findTarget(uint32_t mCellID) const {
    for (int i = 0; i < MAX_TOKEN_CONNECTIONS; ++i) {
        if (this->targetID[i] == mCellID) return i;
    }
    return -1;
}

uint32_t TokenPerceptionEngine::tCell::getTargetID(int index) const {
    if (index >= 0 && index < MAX_TOKEN_CONNECTIONS) return this->targetID[index];
    return 0xFFFFFFFF;
}

int TokenPerceptionEngine::tCell::getUsedTargetCount() const {
    int count = 0;
    for (int i = 0; i < MAX_TOKEN_CONNECTIONS; ++i) {
        if (this->targetID[i] != 0xFFFFFFFF) count++;
    }
    return count;
}

void TokenPerceptionEngine::tCell::clearAllTargets() {
    for (int i = 0; i < MAX_TOKEN_CONNECTIONS; ++i) {
        this->targetID[i] = 0xFFFFFFFF;
    }
}

void TokenPerceptionEngine::tCell::setConnOffset(uint32_t offset) { this->tConnectionOffset = offset; }
uint32_t TokenPerceptionEngine::tCell::getConnOffset() const { return this->tConnectionOffset; }

void TokenPerceptionEngine::tCell::setActive(bool flag) { this->activeFlag = flag; }
bool TokenPerceptionEngine::tCell::isActive() const { return this->activeFlag; }
void TokenPerceptionEngine::tCell::toggleActive() { this->activeFlag = !this->activeFlag; }

void TokenPerceptionEngine::tCell::setLearnable(bool flag) { this->learnable = flag; }
bool TokenPerceptionEngine::tCell::isLearnable() const { return this->learnable; }
void TokenPerceptionEngine::tCell::setExecFlag(bool flag) { this->execFlag = flag; }
bool TokenPerceptionEngine::tCell::isExec() const { return this->execFlag; }

void TokenPerceptionEngine::tCell::autoSetThreshold(const TokenPerceptionEngine::tCellConn* connPool, double ratio) {
    fixed64_t maxEnergy = perceive(this->alias, connPool);
    double f_max = CellMath::fixed64_to_double(maxEnergy);
    this->threshold = CellMath::double_to_fixed64(f_max * ratio);
}

void TokenPerceptionEngine::tCell::trainPattern(const char* targetWord, TokenPerceptionEngine::tCellConn* connPool, size_t connPoolSize, int epochs) {
    if (!connPool || !targetWord) return;

    fixed16_t w_for_1 = CellMath::float_to_fixed16(3.0f);        
    fixed16_t w_for_0 = CellMath::float_to_fixed16(-3.0f);       
    fixed16_t w_for_nothing = CellMath::float_to_fixed16(-5.0f); 

    size_t len = strlen(targetWord);
    int totalBits = len * 8;
    
    int chunksNeeded = (totalBits / MAX_TOKEN_INPUTS) + ((totalBits % MAX_TOKEN_INPUTS != 0) ? 1 : 0);
    if (chunksNeeded == 0) chunksNeeded = 1; 

    for (int epoch = 0; epoch < epochs; ++epoch) {
        int32_t currentChunk = (this->tConnectionOffset == 0xFFFFFFFF) ? NOCONN : (int32_t)this->tConnectionOffset;
        int32_t lastChunk = NOCONN;
        int bitIdx = 0;

        for (int chunkIdx = 0; chunkIdx < chunksNeeded; ++chunkIdx) {
            if (currentChunk == NOCONN) {
                int32_t freeChunk = TokenPerceptionEngine::findFreeTConnChunk(connPool, connPoolSize);
                if (freeChunk == NOCONN) {
                    printf("[Error] tCellConn 메모리 풀 용량 부족! (단어: %s)\n", targetWord);
                    break;
                }
                
                if (lastChunk != NOCONN) {
                    connPool[lastChunk].setNextChunk(freeChunk);
                    connPool[freeChunk].setPrevChunk(lastChunk);
                } else {
                    this->tConnectionOffset = (uint32_t)freeChunk;
                }
                currentChunk = freeChunk;
            }

            for (int slot = 0; slot < MAX_TOKEN_INPUTS; ++slot) {
                int byteIdx = bitIdx / 8;
                int bitInByte = 7 - (bitIdx % 8);

                fixed16_t current_w = connPool[currentChunk].getWeight(slot);
                fixed16_t delta_w = {0, 0};

                if (byteIdx < len) {
                    if ((targetWord[byteIdx] >> bitInByte) & 1) delta_w = w_for_1;
                    else delta_w = w_for_0;
                } else {
                    delta_w = w_for_nothing; 
                }
                connPool[currentChunk].setWeight(slot, CellMath::fixed16_add(current_w, delta_w));
                bitIdx++;
            }
            
            lastChunk = currentChunk;
            currentChunk = connPool[currentChunk].getNextChunk();
        }
    }
}

fixed64_t TokenPerceptionEngine::tCell::perceive(const char* inputWord, const TokenPerceptionEngine::tCellConn* connPool) const {
    if (!connPool || !inputWord) return CellMath::double_to_fixed64(0.0);

    fixed64_t totalEnergy = {0, 0};
    size_t inputLen = strlen(inputWord); 
    size_t targetLen = strlen(this->alias); 
    
    int32_t currentChunk = (this->tConnectionOffset == 0xFFFFFFFF) ? NOCONN : (int32_t)this->tConnectionOffset;
    int bitIdx = 0;

    while (currentChunk != NOCONN) {
        for (int slot = 0; slot < MAX_TOKEN_INPUTS; ++slot) {
            int byteIdx = bitIdx / 8;
            int bitInByte = 7 - (bitIdx % 8);

            fixed16_t w16 = connPool[currentChunk].getWeight(slot);
            fixed64_t w64 = CellMath::fixed16_to_fixed64(w16);
            fixed64_t inputLevel;

            if (byteIdx < targetLen) {
                if (byteIdx < inputLen) {
                    double rawLevel = ((inputWord[byteIdx] >> bitInByte) & 1) ? 1.0 : -1.0;
                    inputLevel = CellMath::double_to_fixed64(rawLevel);
                } else {
                    inputLevel = CellMath::double_to_fixed64(0.0); 
                }
            } else {
                if (byteIdx < inputLen) {
                    double rawLevel = ((inputWord[byteIdx] >> bitInByte) & 1) ? 1.0 : -1.0;
                    inputLevel = CellMath::double_to_fixed64(fabs(rawLevel));
                } else {
                    inputLevel = CellMath::double_to_fixed64(0.0); 
                }
            }

            fixed64_t energyCont = CellMath::fixed64_mul(inputLevel, w64);
            totalEnergy = CellMath::fixed64_add(totalEnergy, energyCont);
            
            bitIdx++;
        }
        currentChunk = connPool[currentChunk].getNextChunk();
    }
    
    int maxTrainedBytes = bitIdx / 8;
    if (inputLen > maxTrainedBytes) {
        double penalty = (inputLen - maxTrainedBytes) * -5.0; 
        totalEnergy = CellMath::fixed64_add(totalEnergy, CellMath::double_to_fixed64(penalty));
    }

    return totalEnergy;
}

// =============================================================================
// [TokenPerceptionEngine::tCellConn] 구현부
// =============================================================================
bool TokenPerceptionEngine::tCellConn::isEmpty() const {
    for (int i = 0; i < MAX_TOKEN_INPUTS; ++i) {
        if (this->weight[i].i != 0 || this->weight[i].f != 0) return false;
    }
    return true;
}

int32_t TokenPerceptionEngine::findFreeTConnChunk(tCellConn* connPool, size_t connPoolSize) {
    if (!connPool) return NOCONN;
    for (size_t i = 0; i < connPoolSize; ++i) {
        if (connPool[i].isEmpty() && !connPool[i].hasPrev() && !connPool[i].hasNext()) {
            return (int32_t)i;
        }
    }
    return NOCONN;
}

void TokenPerceptionEngine::tCellConn::reset() {
    this->toPrevious = NOCONN;
    this->toNext = NOCONN;
    for (int i = 0; i < MAX_TOKEN_INPUTS; ++i) {
        this->weight[i] = {0, 0};
    }
}

void TokenPerceptionEngine::tCellConn::clearWeights() {
    for (int i = 0; i < MAX_TOKEN_INPUTS; ++i) {
        this->weight[i] = {0, 0};
    }
}

int TokenPerceptionEngine::tCellConn::getUsedCount() const {
    int count = 0;
    for (int i = 0; i < MAX_TOKEN_INPUTS; ++i) {
        if (this->weight[i].i != 0 || this->weight[i].f != 0) count++;
    }
    return count;
}

bool TokenPerceptionEngine::tCellConn::isFull() const {
    return getUsedCount() == MAX_TOKEN_INPUTS;
}

void TokenPerceptionEngine::tCellConn::setNextChunk(int32_t relativePos) { this->toNext = relativePos; }
int32_t TokenPerceptionEngine::tCellConn::getNextChunk() const { return this->toNext; }
void TokenPerceptionEngine::tCellConn::setPrevChunk(int32_t relativePos) { this->toPrevious = relativePos; }
int32_t TokenPerceptionEngine::tCellConn::getPrevChunk() const { return this->toPrevious; }
bool TokenPerceptionEngine::tCellConn::hasNext() const { return (this->toNext != NOCONN); }
bool TokenPerceptionEngine::tCellConn::hasPrev() const { return (this->toPrevious != NOCONN); }

fixed16_t TokenPerceptionEngine::tCellConn::getWeight(int slot) const {
    return (slot >= 0 && slot < MAX_TOKEN_INPUTS) ? this->weight[slot] : fixed16_t{0, 0};
}
void TokenPerceptionEngine::tCellConn::setWeight(int slot, fixed16_t w) {
    if (slot >= 0 && slot < MAX_TOKEN_INPUTS) this->weight[slot] = w;
}
void TokenPerceptionEngine::tCellConn::addWeight(int slot, fixed16_t w) {
    if (slot >= 0 && slot < MAX_TOKEN_INPUTS) this->weight[slot] = this->weight[slot] + w;
}
void TokenPerceptionEngine::tCellConn::subWeight(int slot, fixed16_t w) {
    if (slot >= 0 && slot < MAX_TOKEN_INPUTS) this->weight[slot] = this->weight[slot] - w;
}

// =============================================================================
// 🔥 [핵심 추가 알고리즘 공간] 초성 꼬리 물기 내비게이션 엔진 세부 구현
// =============================================================================

// 어절 문자열을 완벽 분석해서 고정 인덱스 테이블의 슬롯 번지로 이정표 매핑해 주는 함수
uint16_t TokenPerceptionEngine::mapEojeolToSlot(const char* eojeol) {
    if (!eojeol || eojeol[0] == '\0') return 999; // 폴백 번지

    uint8_t b1 = static_cast<uint8_t>(eojeol[0]);
    // 1단계: 영숫자, 기호, 표준 ASCII 영역 정밀 배정 (0~255 슬롯 매핑)
    if (b1 < 0x80) {
        return static_cast<uint16_t>(b1); 
    }

    // 2단계: 한글 UTF-8 3바이트 인코딩 패턴 매칭 분석 개시
    if ((b1 & 0xF0) == 0xE0) {
        uint8_t b2 = static_cast<uint8_t>(eojeol[1]);
        uint8_t b3 = static_cast<uint8_t>(eojeol[2]);
        
        if ((b2 & 0xC0) == 0x80 && (b3 & 0xC0) == 0x80) {
            uint32_t uniCode = ((b1 & 0x0F) << 12) | ((b2 & 0x3F) << 6) | (b3 & 0x3F);
            // 한글 음절 전체 도메인 한계선 (AC00 ~ D7A3)
            if (uniCode >= 0xAC00 && uniCode <= 0xD7A3) {
                uint32_t hangulIndex = uniCode - 0xAC00;
                uint32_t chosungIdx = hangulIndex / (21 * 28); // 초성 유도식 (0 ~ 18 추출)
                return static_cast<uint16_t>(256 + chosungIdx); // 256번지부터 한글 초성 매핑 개시
            }
        }
    }
    return static_cast<uint16_t>(700 + (b1 % 200)); // 매칭 실패 예비용 영역 배정
}

// 무작위로 주입된 토큰을 초성 이름표 기반 동적 꼬리 물기 체인에 이어 붙여 정렬해 주는 학습 전용 함수
bool TokenPerceptionEngine::addTokenToChosungChain(tCell* pool, size_t poolSize, uint32_t* chosungIndexPtr, uint32_t newTokenID, const char* alias) {
    if (!pool || !chosungIndexPtr || newTokenID >= poolSize || !alias) return false;

    uint16_t slot = mapEojeolToSlot(alias);
    uint32_t headID = chosungIndexPtr[slot];

    // 케이스 A: 해당 초성에 매칭되는 첫 번째 토큰인 경우 (헤드 등록)
    if (headID == 0xFFFFFFFF) {
        chosungIndexPtr[slot] = newTokenID;
        pool[newTokenID].setPrev(0); // 헤드이므로 이전 링크는 자기 자신 지칭
        pool[newTokenID].setNext(0); // 꼬리이므로 다음 링크는 0 지칭
        return true;
    }

    // 케이스 B: 중복 검사 (오빠 말대로 alias 이름표가 정확히 겹치면 중복 학습 방어망 기동)
    uint32_t checkID = headID;
    while (true) {
        if (strcmp(pool[checkID].getAlias(), alias) == 0) {
            return false; 
        }
        int32_t nextRel = pool[checkID].getNext();
        if (nextRel == 0) break;
        checkID = static_cast<uint32_t>(static_cast<int32_t>(checkID) + nextRel);
    }

    // 케이스 C: 기존 초성 그룹의 맨 마지막 꼬리를 찾아서 꼬리 물기 엮기 진행
    uint32_t currentID = headID;
    while (true) {
        int32_t nextRel = pool[currentID].getNext();
        if (nextRel == 0) { 
            break;
        }
        currentID = static_cast<uint32_t>(static_cast<int32_t>(currentID) + nextRel);
    }

    // 상대 오프셋 정밀 인덱스 연산
    int32_t relToNew = static_cast<int32_t>(newTokenID) - static_cast<int32_t>(currentID);
    int32_t relToPrev = static_cast<int32_t>(currentID) - static_cast<int32_t>(newTokenID);

    pool[currentID].setNext(relToNew);      // 기존 꼬리가 새 토큰을 물어버림
    pool[newTokenID].setPrev(relToPrev);    // 새 토큰의 이전 링크를 기존 꼬리로 고정
    pool[newTokenID].setNext(0);            // 새 토큰이 이제 최종 꼬리가 됨

    return true;
}

// 문장이 들어왔을 때 오빠의 지시대로 어절의 초성만 싹 분석해 딱 필요한 헤드 오프셋만 임시 버퍼에 수집하는 추론 유틸리티
int TokenPerceptionEngine::buildInferenceIndexBuffer(const char* inputSentence, uint32_t* chosungIndexPtr, uint32_t* tmpBuffer, int maxBufferSize) {
    if (!inputSentence || !chosungIndexPtr || !tmpBuffer || maxBufferSize <= 0) return 0;

    int bufferCount = 0;
    char tempSentence[512];
    strncpy(tempSentence, inputSentence, sizeof(tempSentence) - 1);
    tempSentence[sizeof(tempSentence) - 1] = '\0';

    char* token = strtok(tempSentence, " ");
    while (token != nullptr && bufferCount < maxBufferSize) {
        uint16_t slot = mapEojeolToSlot(token);
        uint32_t headID = chosungIndexPtr[slot];

        if (headID != 0xFFFFFFFF) {
            // 중복 스캔을 막기 위한 중복 초성 헤드 ID 필터링
            bool duplicate = false;
            for (int i = 0; i < bufferCount; ++i) {
                if (tmpBuffer[i] == headID) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                tmpBuffer[bufferCount++] = headID;
            }
        }
        token = strtok(nullptr, " ");
    }
    return bufferCount; 
}

// 임시 버퍼의 초성 나침반을 보며 해당 가상메모리 체인만 고속 순회하면서 완벽하게 병렬 매칭 추론하는 핵심 스캔 함수
void TokenPerceptionEngine::scanActiveChosungChains(tCell* pool, const tCellConn* connPool, const uint32_t* tmpBuffer, int bufferSize, const char* inputSentence) {
    if (!pool || !connPool || !tmpBuffer || bufferSize <= 0 || !inputSentence) return;

    for (int i = 0; i < bufferSize; ++i) {
        uint32_t currentID = tmpBuffer[i];
        
        // 초성 꼬리 물기 링크를 한 번씩만 차례대로 미끄러지듯 스캔 수행
        while (true) {
            char wordTarget[64];
            strncpy(wordTarget, pool[currentID].getAlias(), sizeof(wordTarget) - 1);
            wordTarget[sizeof(wordTarget) - 1] = '\0';

            // 비트 인지 코어로 형태 에너지 추출
            fixed64_t energy = pool[currentID].perceive(wordTarget, connPool);
            pool[currentID].setEnergy(energy);

            // 실제 입력 문장과 대입하여 완벽하게 한치 오차도 없이 일치할 때만 플래그 발화
            if (strstr(inputSentence, wordTarget) != nullptr) {
                if (pool[currentID].isOverThreshold()) {
                    pool[currentID].setActive(true); // 활성 비트 On!
                }
            }

            int32_t nextRel = pool[currentID].getNext();
            if (nextRel == 0) { 
                break; // 체인의 맨 끝에 성공적으로 도달
            }
            currentID = static_cast<uint32_t>(static_cast<int32_t>(currentID) + nextRel);
        }
    }
}

TokenPerceptionEngine::TokenPerceptionEngine() {}
TokenPerceptionEngine::~TokenPerceptionEngine() {}