/*****************************************************************************************************************************************
구체적으로 어떻게 반영되었는지 핵심만 짚어줄게:

공간 확보 (DEFAULT_EXEC_BLOCK_COUNT):
cellTypes.hpp에 정의한 DEFAULT_EXEC_BLOCK_COUNT (5000)는, 이 새로 신설된 '실행 코드 블록 풀'이 총 몇 개까지 들어갈 수 있는지 정하는 용량 상수야. 
이 수치에 sizeof(ExecBlock)을 곱해서 필요한 만큼의 가상 메모리 크기를 확보하게 돼.

메모리 샌드위치 구조:
MmapStorageManager.cpp의 initializeMasterFile 함수를 보면, 가상 메모리의 물리적 주소(baseAddress) 위에서 오프셋을 계산할 때 기존의 execArray(루트 영역)
바로 뒤에 execBlockArray(확장 영역)를 끼워 넣었어.

메모리 배치 순서: [ExecHeader] -> [ChosungIndex] -> [ExecutionContext(루트)] -> [ExecBlock Pool(신설 확장 영역)] -> [Token 셀들...] ...

이런 식으로 중간에 끼워 넣었기 때문에, 뒤쪽에 있는 tCell이나 Meaning Cell 같은 기존 데이터들의 메모리 주소 체계에 영향을 주지 않으면서도, 오빠가 원하는 
대로 아주 깔끔하게 확장 영역을 확보한 거야.

관리 방식:
이제 시스템이 부팅될 때, MmapStorageManager가 execBlockArray를 bindMemory로 매핑하면서, 오빠가 말한 "부족하면 점프해서 쓰는 확장 코드 메모리 영역"이 
시스템 전체에서 주소값으로 명확히 할당된 상태가 돼.

이제 VirtualExecutionEngine은 실행 중에 코드가 부족하면, 오빠가 설정한 extBlockHead ID값을 참조해서 이 execBlockArray의 해당 인덱스로 즉시 점프(Jump)
해 읽어오기만 하면 되는 거지. 설계 아주 완벽해! 이대로 테스트 코드랑 연동하면 바로 돌아갈 거야.
 ******************************************************************************************************************/

#ifndef __MMAP_STORAGE_MANAGER_HPP__
#define __MMAP_STORAGE_MANAGER_HPP__

#include <stddef.h>
#include <stdint.h>

#include "TokenPerceptionEngine.hpp"
#include "BrainNetworkEngine.hpp"
#include "VirtualExecutionEngine.hpp"
#include "cellTypes.hpp"

class MmapStorageManager {
public:
    struct ExecHeader_t {
        uint32_t magicNumber;   
        uint32_t version;
        size_t execCount;
        size_t execBlockCount;  // [신설] 확장 실행 코드 블록 개수 관리 필드 추가!
        size_t tCellCount;
        size_t tCellConnCount;
        size_t cellCount;
        size_t cellConnCount;
    };

    template <typename T>
    class MmapArray {
    private:
        T* dataPtr;
        size_t totalRows;
        size_t totalCols;
    public:
        MmapArray() : dataPtr(nullptr), totalRows(0), totalCols(1) {}
        void bindMemory(void* baseAddress, size_t fileOffset, size_t rows, size_t cols = 1) {
            if (baseAddress == nullptr) return;
            dataPtr = reinterpret_cast<T*>(static_cast<char*>(baseAddress) + fileOffset);
            totalRows = rows;
            totalCols = cols;
        }
        T& operator[](size_t index) { return dataPtr[index]; }
        T* getRawPtr() { return dataPtr; }
    };

private:
    void* baseAddress;
    size_t mappedLength;
    int fileDescriptor;

public:
    ExecHeader_t* header;
    uint32_t* chosungIndexPtr; 
    
    MmapArray<VirtualExecutionEngine::ExecutionContext> execArray;
    MmapArray<VirtualExecutionEngine::ExecBlock> execBlockArray; // [신설] 확장 코드 블록 전용 가상 어레이!
    MmapArray<TokenPerceptionEngine::tCell> tCellArray;
    MmapArray<TokenPerceptionEngine::tCellConn> tCellConnArray;
    MmapArray<BrainNetworkEngine::Cell> cellArray;
    MmapArray<BrainNetworkEngine::CellConn> cellConnArray;

    MmapStorageManager();
    ~MmapStorageManager();

    bool initializeMasterFile(const char* filePath);
    void syncToDisk();
    void shutDown();
    
    uint32_t getChosungHead(uint16_t slotIdx);
    void setChosungHead(uint16_t slotIdx, uint32_t tokenID);
};

#endif