#include "SystemManager.hpp"
#include "MmapStorageManager.hpp"     
#include "BrainNetworkEngine.hpp"     
#include <stdio.h>
#include <string.h>                   

SystemManager::SystemManager() {}
SystemManager::~SystemManager() {}

void SystemManager::autoFormatCells(MmapStorageManager& storage, bool isNewFile) {
    if (!isNewFile) {
        return;
    }

    // 🔥 방어 로직 추가: 포인터가 진짜 유효한 메모리인지 철저히 검사
    if (storage.header == nullptr || storage.header == (void*)-1) {
        printf("[Error] 스토리지 헤더 포인터가 유효하지 않습니다! (주소: %p)\n", (void*)storage.header);
        return;
    }

    // 여기서 죽었다면 이제 명확하게 원인을 알 수 있음
    size_t targetCellCount = storage.header->cellCount;
    printf("[System] %lu 개의 의미 셀(Cell)에 고유 ID 각인을 시작합니다...\n", targetCellCount);

    auto rawCellPtr = storage.cellArray.getRawPtr();

    if (rawCellPtr == nullptr) {
        printf("[Error] 가상 메모리 내 의미 셀 배열 주소를 획득하지 못했습니다.\n");
        return;
    }

    for (size_t i = 0; i < targetCellCount; ++i) {
        // C 스타일 초기화를 클래스 멤버 함수 안으로 싹 은닉!
        rawCellPtr[i].initCell((uint32_t)i); 
    }

    storage.syncToDisk();
    printf("[System] 의미 셀(Cell) %lu 개 포맷 및 고유 ID 자동 각인 완벽 대성공.\n", targetCellCount);

    printf("\n==========================================\n");
    printf("[Verify] 초기화된 Cell ID 직접 읽기 검증 (앞부분 3개)\n");
    for (size_t i = 0; i < 3 && i < targetCellCount; ++i) {
        printf(" - Cell 배열 인덱스 [%lu] : 읽어온 ID = %u\n", i, rawCellPtr[i].getID());
    }
    
    printf(" ... (중략) ...\n");
    
    printf("[Verify] 초기화된 Cell ID 직접 읽기 검증 (뒷부분 3개)\n");
    size_t startLast = (targetCellCount > 3) ? (targetCellCount - 3) : 0;
    for (size_t i = startLast; i < targetCellCount; ++i) {
        printf(" - Cell 배열 인덱스 [%lu] : 읽어온 ID = %u\n", i, rawCellPtr[i].getID());
    }
    printf("==========================================\n\n");
}

void SystemManager::processForgetMechanism(uint32_t loginCount) {}
void SystemManager::manageSystemClock() {}